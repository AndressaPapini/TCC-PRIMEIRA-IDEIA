# SENAI FLOW — Como abrir no seu computador

Este pacote contém o protótipo local do **SENAI FLOW**, desenvolvido em React, TypeScript, Vite e Tailwind CSS para o SENAI A. Jacob Lafer.

## Requisitos

Instale o **Node.js 20 ou superior** pelo site oficial: https://nodejs.org/

Depois, abra o Terminal (macOS/Linux) ou PowerShell (Windows) na pasta do projeto.

## Instalação

```bash
npm install
```

## Executar o projeto

```bash
npm run dev
```

O terminal exibirá um endereço semelhante a:

```text
http://localhost:5173
```

Abra esse endereço no Chrome, Edge ou Firefox.

## Verificação de produção

Para gerar a versão compilada:

```bash
npm run build
```

## Funcionalidades disponíveis

O protótipo inclui navegação superior responsiva, dashboard, autorizações de saída, integração simulada com a Portaria, reserva de salas, controle de uniformes, alunos, carômetro, notificações e relatórios. Os dados são mockados e persistidos no `localStorage` do navegador.

Para restaurar os dados originais da demonstração, abra o menu do perfil **Coordenação** no canto superior direito e escolha **Restaurar dados de demonstração**.

## Observação

O pacote não inclui credenciais, arquivos de configuração da plataforma Manus, dependências instaladas ou dados privados. Esses itens são recriados ou instalados localmente com os comandos acima.


## Data e horário

A tela de Liberação de Alunos usa automaticamente a **data e o horário atuais do computador**. Ao abrir o sistema em um novo dia, os dados de demonstração de presença são atualizados para a data atual.
