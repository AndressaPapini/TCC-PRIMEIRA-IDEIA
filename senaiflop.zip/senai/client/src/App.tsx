import React from "react";
import { Route, Switch } from "wouter";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { FlowDataProvider } from "./contexts/FlowDataContext";
import { TopNav } from "./components/TopNav";

// Pages
import { Home } from "./pages/Home";
import { AuthorizationsPage } from "./pages/AuthorizationsPage";
import { PortariaPage } from "./pages/PortariaPage";
import { SalasPage } from "./pages/SalasPage";
import { UniformesPage } from "./pages/UniformesPage";
import { AlunosPage } from "./pages/AlunosPage";
import { NotificacoesPage, RelatoriosPage } from "./pages/ReportsAndNotifPage";
import { StudentReleasePage } from "./pages/StudentReleasePage";
import NotFound from "./pages/NotFound";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/autorizacoes" component={AuthorizationsPage} />
      <Route path="/liberacao-alunos" component={StudentReleasePage} />
      <Route path="/portaria" component={PortariaPage} />
      <Route path="/salas" component={SalasPage} />
      <Route path="/uniformes" component={UniformesPage} />
      <Route path="/alunos" component={() => <AlunosPage initialMode="lista" />} />
      <Route path="/carometro" component={() => <AlunosPage initialMode="carometro" />} />
      <Route path="/notificacoes" component={NotificacoesPage} />
      <Route path="/relatorios" component={RelatoriosPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <FlowDataProvider>
        <TooltipProvider>
          <div className="min-h-screen flex flex-col bg-white text-slate-950 font-sans selection:bg-red-600 selection:text-slate-950">
            {/* Top Fixed Header with Brand, Navigation & User Controls */}
            <TopNav />

            {/* Main Application Content Area */}
            <main className="flex-1">
              <Router />
            </main>

            {/* Subtle Footer for TCC Context */}
            <footer className="py-6 border-t border-red-100 bg-[#fff7f7] text-center text-xs text-slate-500">
              <div className="container max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-700">SENAI FLOW</span>
                  <span>•</span>
                  <span>SENAI A. Jacob Lafer — Santo André</span>
                </div>
                <div className="text-[11px] text-slate-500">
                  Protótipo TCC — Técnico em Desenvolvimento de Sistemas
                </div>
              </div>
            </footer>
          </div>

          <Toaster position="top-right" richColors />
        </TooltipProvider>
      </FlowDataProvider>
    </ErrorBoundary>
  );
}
