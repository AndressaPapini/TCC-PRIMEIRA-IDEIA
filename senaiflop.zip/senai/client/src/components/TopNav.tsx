import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { useFlowData } from "@/contexts/FlowDataContext";
import {
  Bell,
  Search,
  User,
  Menu,
  X,
  Sparkles,
  ChevronDown,
  ShieldCheck,
  CheckCircle2,
  Clock,
  DoorOpen,
  Building2,
  Shirt,
  Users,
  BarChart3,
  LogOut,
  RotateCcw
} from "lucide-react";
import { toast } from "sonner";

interface TopNavProps {
  onOpenQuickSearch?: () => void;
}

export const TopNav: React.FC<TopNavProps> = () => {
  const [location, setLocation] = useLocation();
  const { notifications, unreadNotificationsCount, markNotificationsAsRead, resetAllData } = useFlowData();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const navLinks = [
    { label: "Início", path: "/" },
    { label: "Alunos", path: "/alunos" },
    { label: "Carômetro", path: "/carometro" },
    { label: "Autorizações", path: "/autorizacoes" },
    { label: "Liberação", path: "/liberacao-alunos" },
    { label: "Salas", path: "/salas" },
    { label: "Uniformes", path: "/uniformes" },
    { label: "Portaria", path: "/portaria" },
    { label: "Relatórios", path: "/relatorios" },
    { label: "Notificações", path: "/notificacoes" }
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    toast.info(`Buscando por: "${searchQuery}"`, {
      description: "Navegando para o diretório de alunos correspondente."
    });
    setLocation(`/alunos?q=${encodeURIComponent(searchQuery.trim())}`);
    setSearchQuery("");
  };

  const handleResetData = () => {
    resetAllData();
    toast.success("Dados restaurados para o padrão de demonstração!", {
      description: "Todas as atividades e estoques voltaram ao estado inicial."
    });
    setUserMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full glass-header backdrop-blur-xl border-b border-red-100 transition-colors">
      <div className="container max-w-[1400px] mx-auto flex items-center justify-between h-20 px-3 sm:px-5">
        
        {/* Left: Brand Identity */}
        <Link href="/" className="flex items-center gap-2.5 sm:gap-3 group cursor-pointer focus:outline-none shrink-0">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 via-red-700 to-red-700 shadow-md shadow-red-900/40 border border-red-400/30 group-hover:scale-105 transition-transform duration-200">
            <span className="font-extrabold text-slate-950 tracking-wider text-xs">SENAI</span>
            <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-red-600 border-2 border-[#0b1120]" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-bold tracking-tight text-slate-950 text-sm sm:text-base flex items-center gap-1.5">
                SENAI FLOW
                <span className="text-[9px] font-semibold tracking-wider uppercase px-1.5 py-0.5 rounded-full bg-red-500/20 text-red-600 border border-red-500/30">
                  v1.0 TCC
                </span>
              </span>
            </div>
            <span className="text-[11px] text-slate-500 tracking-wide font-medium">
              A. Jacob Lafer
            </span>
          </div>
        </Link>

        {/* Center: Desktop Navigation Links (TOP NAV ONLY, NO SIDEBAR) */}
        <nav className="hidden lg:flex items-center gap-0.5 xl:gap-1">
          {navLinks.map((item) => {
            const isActive = location === item.path || (item.path !== "/" && location.startsWith(item.path));
            return (
              <Link
                key={item.path}
                href={item.path}
                className={`relative px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium rounded-lg transition-all duration-200 cursor-pointer whitespace-nowrap ${
                  isActive
                    ? "text-slate-950 bg-red-600/30 border border-red-500/40 shadow-sm shadow-red-500/20"
                    : "text-slate-700 hover:text-slate-950 hover:bg-white/5"
                }`}
              >
                {item.label}
                {item.path === "/notificacoes" && unreadNotificationsCount > 0 && (
                  <span className="ml-1 inline-flex items-center justify-center px-1.5 py-0.2 text-[9px] font-bold text-slate-950 bg-red-600 rounded-full animate-pulse">
                    {unreadNotificationsCount}
                  </span>
                )}
                {isActive && (
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-red-400 rounded-full shadow-[0_0_8px_#38bdf8]" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Right: Search, Notifications & Profile */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* Quick Search Field */}
          <form onSubmit={handleSearchSubmit} className="hidden 2xl:flex relative items-center">
            <Search className="absolute left-3 w-3.5 h-3.5 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar aluno, sala..."
              className="w-40 xl:w-48 h-8.5 pl-8 pr-2.5 rounded-xl bg-white border border-red-100 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-red-500"
            />
          </form>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setNotifDropdownOpen(!notifDropdownOpen);
                setUserMenuOpen(false);
              }}
              className="relative p-2 rounded-xl bg-white hover:bg-red-50 border border-red-100 text-slate-700 hover:text-slate-950 transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-red-500/40"
              title="Notificações"
              aria-label="Notificações"
            >
              <Bell className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-[#0b1120] animate-ping" />
              )}
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-[#0b1120]" />
              )}
            </button>

            {/* Dropdown Panel */}
            {notifDropdownOpen && (
              <div className="absolute right-0 mt-3 w-80 sm:w-96 rounded-2xl bg-white border border-red-100 shadow-2xl shadow-black/80 py-3 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between px-4 pb-2 border-b border-red-100">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-slate-950">Notificações</span>
                    {unreadNotificationsCount > 0 && (
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-red-600/30 text-red-600 border border-red-500/30">
                        {unreadNotificationsCount} novas
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => {
                      markNotificationsAsRead();
                      toast.success("Todas as notificações foram marcadas como lidas.");
                    }}
                    className="text-xs text-red-600 hover:text-red-600 transition-colors cursor-pointer"
                  >
                    Marcar lidas
                  </button>
                </div>

                <div className="max-h-72 overflow-y-auto custom-scrollbar divide-y divide-white/5">
                  {notifications.slice(0, 5).map((n) => (
                    <div
                      key={n.id}
                      className={`px-4 py-3 hover:bg-white/5 transition-colors cursor-pointer ${
                        n.unread ? "bg-red-50/20" : ""
                      }`}
                      onClick={() => {
                        setNotifDropdownOpen(false);
                        setLocation("/notificacoes");
                      }}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-xs font-medium text-slate-950 line-clamp-1">{n.title}</span>
                        <span className="text-[10px] text-slate-500 font-mono whitespace-nowrap">{n.time}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{n.description}</p>
                    </div>
                  ))}
                </div>

                <div className="px-3 pt-2 border-t border-red-100">
                  <Link
                    href="/notificacoes"
                    onClick={() => setNotifDropdownOpen(false)}
                    className="block text-center py-1.5 text-xs font-medium text-red-600 hover:text-red-600 hover:bg-red-500/10 rounded-lg transition-colors"
                  >
                    Ver todas as notificações →
                  </Link>
                </div>
              </div>
            )}
          </div>

          {/* User Profile / Menu */}
          <div className="relative">
            <button
              onClick={() => {
                setUserMenuOpen(!userMenuOpen);
                setNotifDropdownOpen(false);
              }}
              className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-white hover:bg-red-50 border border-red-100 transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-red-500/40"
            >
              <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-red-700 to-red-600 flex items-center justify-center font-bold text-slate-950 text-xs border border-red-400/40 shadow-inner">
                CP
              </div>
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-xs font-semibold text-slate-900">Coordenação</span>
                <span className="text-[9px] text-red-600 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
                  Ativo
                </span>
              </div>
              <ChevronDown className="hidden sm:block w-3 h-3 text-slate-500" />
            </button>

            {/* Profile Dropdown */}
            {userMenuOpen && (
              <div className="absolute right-0 mt-3 w-64 rounded-2xl bg-white border border-red-100 shadow-2xl shadow-black/80 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-4 py-2.5 border-b border-red-100">
                  <p className="text-xs font-bold text-slate-950">Coordenação Pedagógica</p>
                  <p className="text-[11px] text-slate-500">coordenacao.jacoblafer@sp.senai.br</p>
                  <p className="text-[10px] text-red-600 font-medium mt-1">Nível de Acesso: Administrador</p>
                </div>

                <div className="py-1">
                  <button
                    onClick={handleResetData}
                    className="w-full text-left px-4 py-2 text-xs text-red-600 hover:bg-red-500/10 flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Restaurar dados de demonstração
                  </button>
                  <Link
                    href="/relatorios"
                    onClick={() => setUserMenuOpen(false)}
                    className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <BarChart3 className="w-3.5 h-3.5" />
                    Relatórios gerenciais
                  </Link>
                </div>

                <div className="border-t border-red-100 pt-1">
                  <button
                    onClick={() => {
                      toast.info("Demonstração de TCC", {
                        description: "O protótipo permanece logado como Coordenação para avaliação contínua da banca."
                      });
                      setUserMenuOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-slate-500 hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Encerrar simulação
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Mobile Menu Toggle (NO SIDEBAR, ONLY MOBILE TOP DROPDOWN) */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl bg-white hover:bg-red-50 border border-red-100 text-slate-700 hover:text-slate-950 transition-all cursor-pointer"
            aria-label="Abrir menu de navegação superior"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Top Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden px-4 pt-2 pb-6 bg-white/95 backdrop-blur-2xl border-b border-red-100 animate-in slide-in-from-top-4 duration-200">
          <form onSubmit={handleSearchSubmit} className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar aluno, sala, placa..."
                className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-red-100 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-red-500"
              />
            </div>
          </form>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {navLinks.map((item) => {
              const isActive = location === item.path;
              return (
                <Link
                  key={item.path}
                  href={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium cursor-pointer transition-colors ${
                    isActive
                      ? "bg-red-600 text-slate-950 font-semibold"
                      : "bg-white text-slate-700 hover:bg-white/5 hover:text-slate-950"
                  }`}
                >
                  <span>{item.label}</span>
                  {item.path === "/notificacoes" && unreadNotificationsCount > 0 && (
                    <span className="px-1.5 py-0.5 text-[10px] bg-red-600 text-slate-950 rounded-full font-bold">
                      {unreadNotificationsCount}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-red-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>SENAI A. Jacob Lafer • TCC DS</span>
            <button
              onClick={handleResetData}
              className="text-red-600 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              Restaurar dados
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
