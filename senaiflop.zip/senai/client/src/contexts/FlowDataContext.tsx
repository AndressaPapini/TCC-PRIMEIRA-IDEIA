import React, { createContext, useContext, useEffect, useState } from "react";
import {
  Student,
  ExitAuthorization,
  Room,
  UniformItem,
  UniformWithdrawal,
  GateMovement,
  RealtimeActivity,
  FlowNotification,
  INITIAL_STUDENTS,
  INITIAL_AUTHORIZATIONS,
  INITIAL_ROOMS,
  INITIAL_UNIFORMS,
  INITIAL_WITHDRAWALS,
  INITIAL_GATE_MOVEMENTS,
  INITIAL_ACTIVITIES,
  INITIAL_NOTIFICATIONS
} from "../data/mockData";
import {
  AttendanceStudent,
  INITIAL_ATTENDANCE_STUDENTS,
  INITIAL_REGISTROS_ENTRADA,
  RegistroEntrada
} from "../data/attendanceData";

interface FlowDataContextType {
  students: Student[];
  alunos: AttendanceStudent[];
  registrosEntrada: RegistroEntrada[];
  authorizations: ExitAuthorization[];
  rooms: Room[];
  uniforms: UniformItem[];
  withdrawals: UniformWithdrawal[];
  gateMovements: GateMovement[];
  activities: RealtimeActivity[];
  notifications: FlowNotification[];
  unreadNotificationsCount: number;
  simulatedTime: string;
  simulatedDate: string;
  authorizeStudent: (authId: string, options?: { note?: string }) => void;
  rejectAuthorization: (authId: string, reason?: string) => void;
  createAuthorization: (payload: {
    studentName: string;
    studentClass: string;
    reason: string;
    time: string;
    requestedBy: string;
    guardianName: string;
    guardianPhone: string;
  }) => void;
  confirmGateExit: (authId: string) => void;
  reserveRoom: (payload: {
    roomId: string;
    startTime: string;
    endTime: string;
    date: string;
    responsible: string;
    purpose: string;
    classGroup?: string;
  }) => void;
  registerUniformWithdrawal: (payload: {
    studentName: string;
    studentClass: string;
    itemType: "Camiseta" | "Calça" | "Bermuda" | "Jaqueta";
    size: string;
    quantity: number;
    registeredBy: string;
  }) => { success: boolean; message?: string; previousStock?: number; remainingStock?: number };
  registerVehicleMovement: (payload: {
    plate: string;
    driver: string;
    type: "Entrada" | "Saída";
    destination?: string;
  }) => void;
  markNotificationsAsRead: () => void;
  authorizeRelease: (recordId: string, coordinator: string) => { success: boolean; message?: string };
  confirmRelease: (recordId: string) => { success: boolean; message?: string; horario_saida?: string };
  resetAllData: () => void;
}

const STORAGE_KEY = "senai_flow_data_v1";

const FlowDataContext = createContext<FlowDataContextType | null>(null);

export const FlowDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_students`);
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [alunos] = useState<AttendanceStudent[]>(INITIAL_ATTENDANCE_STUDENTS);

  const [registrosEntrada, setRegistrosEntrada] = useState<RegistroEntrada[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_attendance`);
    if (!saved) return INITIAL_REGISTROS_ENTRADA;

    const parsed = JSON.parse(saved) as RegistroEntrada[];
    const today = new Date().toLocaleDateString("pt-BR");
    const hasTodayRecords = parsed.some((record) => record.data === today);

    // Ao virar o dia, cria uma nova demonstração para a data real do computador,
    // evitando que a tela fique vazia por causa dos dados salvos do dia anterior.
    if (!hasTodayRecords && parsed.length > 0) {
      return parsed.map((record) => ({
        ...record,
        data: today,
        horario_saida: null,
        status: record.status === "Saiu" ? "Presente" : record.status,
        liberacao_autorizada: false,
        liberacao_coordenador: "",
        liberacao_confirmada: false,
      }));
    }

    return parsed;
  });

  const [authorizations, setAuthorizations] = useState<ExitAuthorization[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_auths`);
    return saved ? JSON.parse(saved) : INITIAL_AUTHORIZATIONS;
  });

  const [rooms, setRooms] = useState<Room[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_rooms`);
    return saved ? JSON.parse(saved) : INITIAL_ROOMS;
  });

  const [uniforms, setUniforms] = useState<UniformItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_uniforms`);
    return saved ? JSON.parse(saved) : INITIAL_UNIFORMS;
  });

  const [withdrawals, setWithdrawals] = useState<UniformWithdrawal[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_withdrawals`);
    return saved ? JSON.parse(saved) : INITIAL_WITHDRAWALS;
  });

  const [gateMovements, setGateMovements] = useState<GateMovement[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_gate`);
    return saved ? JSON.parse(saved) : INITIAL_GATE_MOVEMENTS;
  });

  const [activities, setActivities] = useState<RealtimeActivity[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_activities`);
    return saved ? JSON.parse(saved) : INITIAL_ACTIVITIES;
  });

  const [notifications, setNotifications] = useState<FlowNotification[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_notifications`);
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const now = new Date();
  const simulatedTime = now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  const simulatedDate = now.toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  });

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_students`, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_attendance`, JSON.stringify(registrosEntrada));
  }, [registrosEntrada]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_auths`, JSON.stringify(authorizations));
  }, [authorizations]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_rooms`, JSON.stringify(rooms));
  }, [rooms]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_uniforms`, JSON.stringify(uniforms));
  }, [uniforms]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_withdrawals`, JSON.stringify(withdrawals));
  }, [withdrawals]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_gate`, JSON.stringify(gateMovements));
  }, [gateMovements]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_activities`, JSON.stringify(activities));
  }, [activities]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(notifications));
  }, [notifications]);

  const addActivity = (title: string, description: string, badge: string, badgeVariant: RealtimeActivity["badgeVariant"]) => {
    const newAct: RealtimeActivity = {
      id: `act-${Date.now()}`,
      time: simulatedTime,
      title,
      description,
      badge,
      badgeVariant,
      timestamp: Date.now()
    };
    setActivities(prev => [newAct, ...prev]);
  };

  const addNotification = (title: string, description: string, iconType: FlowNotification["iconType"]) => {
    const newNotif: FlowNotification = {
      id: `notif-${Date.now()}`,
      title,
      description,
      time: simulatedTime,
      iconType,
      unread: true,
      timestamp: Date.now()
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const authorizeStudent = (authId: string, options?: { note?: string }) => {
    let studentTargetName = "";
    let studentTargetClass = "";
    let reasonText = "";
    let scheduledTime = "";

    setAuthorizations(prev =>
      prev.map(auth => {
        if (auth.id === authId) {
          studentTargetName = auth.studentName;
          studentTargetClass = auth.studentClass;
          reasonText = auth.reason;
          scheduledTime = auth.time;
          return {
            ...auth,
            status: "Autorizado",
            decisionAt: simulatedTime,
            decidedBy: "Coordenação Pedagógica"
          };
        }
        return auth;
      })
    );

    // Update student status & history
    setStudents(prev =>
      prev.map(s => {
        if (s.name.toLowerCase() === studentTargetName.toLowerCase()) {
          return {
            ...s,
            status: "Liberado",
            authorizationsHistory: [
              {
                id: `auth-hist-${Date.now()}`,
                reason: reasonText || "Autorização de saída",
                date: now.toLocaleDateString("pt-BR"),
                time: scheduledTime || simulatedTime,
                status: "Autorizado",
                requestedBy: "Coordenação Pedagógica"
              },
              ...s.authorizationsHistory
            ]
          };
        }
        return s;
      })
    );

    // Add to gate movements as synchronized authorization
    setGateMovements(prev => [
      {
        id: `gate-sync-${Date.now()}`,
        type: "Saída",
        title: studentTargetName || "Aluno autorizado",
        subtitle: `${studentTargetClass} • Saída programada às ${scheduledTime} • Aguardando passagem pela portaria`,
        tag: "Autorizado",
        time: simulatedTime,
        status: "Pendente na catraca"
      },
      ...prev
    ]);

    addActivity(
      studentTargetName || "Aluno",
      `Saída autorizada • Horário: ${scheduledTime} • Encaminhado para a portaria`,
      "Autorizado",
      "success"
    );

    addNotification(
      "✓ Nova saída autorizada",
      `${studentTargetName} — ${studentTargetClass} liberado para saída às ${scheduledTime}`,
      "authorization"
    );
  };

  const rejectAuthorization = (authId: string, reason?: string) => {
    let studentTargetName = "";
    let studentTargetClass = "";

    setAuthorizations(prev =>
      prev.map(auth => {
        if (auth.id === authId) {
          studentTargetName = auth.studentName;
          studentTargetClass = auth.studentClass;
          return {
            ...auth,
            status: "Recusado",
            decisionAt: simulatedTime,
            decidedBy: "Coordenação Pedagógica"
          };
        }
        return auth;
      })
    );

    addActivity(
      studentTargetName || "Solicitação",
      `Saída recusada pela coordenação • ${reason || "Motivo informado ao solicitante"}`,
      "Recusado",
      "destructive"
    );

    addNotification(
      "✕ Saída não autorizada",
      `Solicitação de ${studentTargetName} (${studentTargetClass}) foi recusada pela Coordenação`,
      "authorization"
    );
  };

  const createAuthorization = (payload: {
    studentName: string;
    studentClass: string;
    reason: string;
    time: string;
    requestedBy: string;
    guardianName: string;
    guardianPhone: string;
  }) => {
    const newAuth: ExitAuthorization = {
      id: `AUTH-2026-${Math.floor(100 + Math.random() * 900)}`,
      studentId: `std-${Date.now()}`,
      studentName: payload.studentName,
      studentClass: payload.studentClass,
      reason: payload.reason,
      time: payload.time,
      date: now.toLocaleDateString("pt-BR"),
      requestedBy: payload.requestedBy || "Coordenação",
      guardianName: payload.guardianName,
      guardianPhone: payload.guardianPhone,
      status: "Pendente",
      urgent: false
    };

    setAuthorizations(prev => [newAuth, ...prev]);

    addActivity(
      newAuth.studentName,
      `Nova solicitação de saída • Horário: ${newAuth.time} • Enviada para coordenação`,
      "Pendente",
      "destructive"
    );

    addNotification(
      "📋 Nova solicitação de saída",
      `${newAuth.studentName} (${newAuth.studentClass}) — ${newAuth.reason}`,
      "authorization"
    );
  };

  const confirmGateExit = (authId: string) => {
    let sName = "";
    let sClass = "";

    setAuthorizations(prev =>
      prev.map(auth => {
        if (auth.id === authId) {
          sName = auth.studentName;
          sClass = auth.studentClass;
          return {
            ...auth,
            gateConfirmedAt: simulatedTime
          };
        }
        return auth;
      })
    );

    // Register actual gate exit
    setGateMovements(prev => [
      {
        id: `gate-exit-${Date.now()}`,
        type: "Saída",
        title: sName || "Aluno liberado",
        subtitle: `${sClass} • Saída presencial confirmada pela Portaria`,
        tag: "Saída",
        time: simulatedTime,
        status: "Concluído"
      },
      ...prev
    ]);

    addActivity(
      sName || "Aluno",
      `Saída física confirmada na Portaria Principal às ${simulatedTime}`,
      "Saída",
      "default"
    );

    addNotification(
      "🚪 Saída física confirmada",
      `${sName} registrou passagem pela catraca da portaria às ${simulatedTime}`,
      "security"
    );
  };

  const reserveRoom = (payload: {
    roomId: string;
    startTime: string;
    endTime: string;
    date: string;
    responsible: string;
    purpose: string;
    classGroup?: string;
  }) => {
    let roomName = "";

    setRooms(prev =>
      prev.map(room => {
        if (room.id === payload.roomId) {
          roomName = room.name;
          const newReservation = {
            id: `res-${Date.now()}`,
            startTime: payload.startTime,
            endTime: payload.endTime,
            date: payload.date || now.toLocaleDateString("pt-BR"),
            responsible: payload.responsible,
            purpose: payload.purpose,
            classGroup: payload.classGroup
          };
          return {
            ...room,
            status: "Reservado" as const,
            reservations: [...room.reservations, newReservation]
          };
        }
        return room;
      })
    );

    addActivity(
      roomName || "Espaço Escolar",
      `Sala reservada • ${payload.startTime} às ${payload.endTime} • ${payload.responsible}`,
      "Reservado",
      "warning"
    );

    addNotification(
      "🟡 Sala reservada",
      `${roomName} — ${payload.startTime} às ${payload.endTime} por ${payload.responsible}`,
      "room"
    );
  };

  const registerUniformWithdrawal = (payload: {
    studentName: string;
    studentClass: string;
    itemType: "Camiseta" | "Calça" | "Bermuda" | "Jaqueta";
    size: string;
    quantity: number;
    registeredBy: string;
  }) => {
    const item = uniforms.find(u => u.type === payload.itemType && u.size === payload.size);
    if (!item) {
      return { success: false, message: "Item não encontrado no catálogo." };
    }
    if (item.quantity < payload.quantity) {
      return { success: false, message: `Quantidade insuficiente em estoque. Disponível: ${item.quantity}.` };
    }

    const previousStock = item.quantity;
    const remainingStock = previousStock - payload.quantity;

    // Update uniform inventory
    setUniforms(prev =>
      prev.map(u => {
        if (u.id === item.id) {
          const newStatus: "Crítico" | "Baixo" | "Normal" =
            remainingStock <= 5 ? "Crítico" : remainingStock <= u.minimumSafe ? "Baixo" : "Normal";
          return {
            ...u,
            quantity: remainingStock,
            status: newStatus
          };
        }
        return u;
      })
    );

    // Record withdrawal history
    const newWithdrawal: UniformWithdrawal = {
      id: `with-${Date.now()}`,
      studentName: payload.studentName,
      studentClass: payload.studentClass,
      itemType: payload.itemType,
      size: payload.size,
      quantity: payload.quantity,
      date: now.toLocaleDateString("pt-BR"),
      time: simulatedTime,
      registeredBy: payload.registeredBy || "Coordenação / Almoxarifado",
      previousStock,
      remainingStock
    };

    setWithdrawals(prev => [newWithdrawal, ...prev]);

    addActivity(
      `${payload.itemType} ${payload.size}`,
      `Retirada registrada • Aluno: ${payload.studentName} (${payload.studentClass}) • Restante: ${remainingStock}`,
      `Qtd: ${payload.quantity}`,
      "secondary"
    );

    addNotification(
      "👕 Uniforme retirado",
      `${payload.itemType} ${payload.size} — ${payload.quantity} unid. para ${payload.studentName}`,
      "uniform"
    );

    return {
      success: true,
      previousStock,
      remainingStock
    };
  };

  const registerVehicleMovement = (payload: {
    plate: string;
    driver: string;
    type: "Entrada" | "Saída";
    destination?: string;
  }) => {
    const movement: GateMovement = {
      id: `gate-veh-${Date.now()}`,
      type: "Veículo",
      title: `Veículo ${payload.plate}`,
      subtitle: `${payload.driver} • ${payload.destination || "Estacionamento Interno"}`,
      tag: payload.type,
      time: simulatedTime,
      status: "Registrado",
      plate: payload.plate,
      driver: payload.driver,
      destination: payload.destination
    };

    setGateMovements(prev => [movement, ...prev]);

    addActivity(
      `Veículo ${payload.plate}`,
      `${payload.type} registrada • Condutor: ${payload.driver}`,
      payload.type,
      "default"
    );

    addNotification(
      "🚗 Veículo registrado",
      `${payload.plate} — ${payload.type} autorizada no portão veicular`,
      "vehicle"
    );
  };

  const markNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, unread: false })));
  };

  const authorizeRelease = (recordId: string, coordinator: string) => {
    if (!coordinator.trim()) return { success: false, message: "Informe o nome do coordenador." };
    const target = registrosEntrada.find(record => record.id === recordId);
    if (!target) return { success: false, message: "Registro de entrada não encontrado." };
    if (target.status === "Saiu") return { success: false, message: "Este aluno já saiu do campus." };
    setRegistrosEntrada(prev => prev.map(record => record.id === recordId ? { ...record, liberacao_autorizada: true, liberacao_coordenador: coordinator.trim() } : record));
    addActivity(target.nome, `Saída autorizada por ${coordinator.trim()} • Aguardando confirmação da portaria`, "Aguardando portaria", "warning");
    addNotification("🔐 Saída aguardando portaria", `${target.nome} foi autorizado por ${coordinator.trim()}.`, "authorization");
    return { success: true };
  };

  const confirmRelease = (recordId: string) => {
    const target = registrosEntrada.find(record => record.id === recordId);
    if (!target) return { success: false, message: "Registro de entrada não encontrado." };
    if (!target.liberacao_autorizada) return { success: false, message: "A Coordenação ainda não autorizou esta saída." };
    const horario_saida = new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    setRegistrosEntrada(prev => prev.map(record => record.id === recordId ? { ...record, liberacao_confirmada: true, horario_saida, status: "Saiu" } : record));
    addActivity(target.nome, `Saída física confirmada pela Portaria às ${horario_saida}`, "Saiu", "success");
    addNotification("🚪 Saída confirmada", `${target.nome} deixou o campus às ${horario_saida}.`, "security");
    return { success: true, horario_saida };
  };

  const resetAllData = () => {
    localStorage.removeItem(`${STORAGE_KEY}_students`);
    localStorage.removeItem(`${STORAGE_KEY}_auths`);
    localStorage.removeItem(`${STORAGE_KEY}_rooms`);
    localStorage.removeItem(`${STORAGE_KEY}_uniforms`);
    localStorage.removeItem(`${STORAGE_KEY}_withdrawals`);
    localStorage.removeItem(`${STORAGE_KEY}_gate`);
    localStorage.removeItem(`${STORAGE_KEY}_activities`);
    localStorage.removeItem(`${STORAGE_KEY}_notifications`);
    localStorage.removeItem(`${STORAGE_KEY}_attendance`);

    setStudents(INITIAL_STUDENTS);
    setAuthorizations(INITIAL_AUTHORIZATIONS);
    setRooms(INITIAL_ROOMS);
    setUniforms(INITIAL_UNIFORMS);
    setWithdrawals(INITIAL_WITHDRAWALS);
    setGateMovements(INITIAL_GATE_MOVEMENTS);
    setActivities(INITIAL_ACTIVITIES);
    setNotifications(INITIAL_NOTIFICATIONS);
    setRegistrosEntrada(INITIAL_REGISTROS_ENTRADA);
  };

  const unreadNotificationsCount = notifications.filter(n => n.unread).length;

  return (
    <FlowDataContext.Provider
      value={{
        students,
        alunos,
        registrosEntrada,
        authorizations,
        rooms,
        uniforms,
        withdrawals,
        gateMovements,
        activities,
        notifications,
        unreadNotificationsCount,
        simulatedTime,
        simulatedDate,
        authorizeStudent,
        rejectAuthorization,
        createAuthorization,
        confirmGateExit,
        reserveRoom,
        registerUniformWithdrawal,
        registerVehicleMovement,
        markNotificationsAsRead,
        authorizeRelease,
        confirmRelease,
        resetAllData
      }}
    >
      {children}
    </FlowDataContext.Provider>
  );
};

export const useFlowData = () => {
  const context = useContext(FlowDataContext);
  if (!context) {
    throw new Error("useFlowData must be used within a FlowDataProvider");
  }
  return context;
};
