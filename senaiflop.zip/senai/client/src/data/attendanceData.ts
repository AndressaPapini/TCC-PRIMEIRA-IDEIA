export type AttendanceStatus = "Presente" | "Ausente" | "Saiu" | "Entrada registrada";

export type AttendanceStudent = {
  id: string;
  name: string;
  matricula: string;
  turma: string;
  sala: string;
  curso: string;
};

export type RegistroEntrada = {
  id: string;
  aluno_id: string;
  nome: string;
  data: string;
  horario_entrada: string;
  horario_saida: string | null;
  status: AttendanceStatus;
  liberacao_autorizada: boolean;
  liberacao_coordenador: string;
  liberacao_confirmada: boolean;
};

export const getTodayKey = () => {
  const now = new Date();
  return now.toLocaleDateString("pt-BR");
};

// Data real do computador no momento em que o app é carregado.
export const TODAY_KEY = getTodayKey();

export const INITIAL_ATTENDANCE_STUDENTS: AttendanceStudent[] = [
  { id: "aluno-001", name: "João Silva", matricula: "DS-2026-084", turma: "DS 2", sala: "Sala 101", curso: "Técnico em Desenvolvimento de Sistemas" },
  { id: "aluno-002", name: "Maria Clara", matricula: "DS-2026-042", turma: "DS 2", sala: "Sala 102", curso: "Técnico em Desenvolvimento de Sistemas" },
  { id: "aluno-003", name: "Pedro Henrique", matricula: "DS-2026-118", turma: "DS 1", sala: "Laboratório", curso: "Técnico em Desenvolvimento de Sistemas" },
  { id: "aluno-004", name: "Beatriz Oliveira", matricula: "DS-2026-015", turma: "DS 2", sala: "Sala 104", curso: "Técnico em Desenvolvimento de Sistemas" },
  { id: "aluno-005", name: "Gabriel Santos", matricula: "EL-2026-033", turma: "Eletro 1", sala: "Laboratório 2", curso: "Técnico em Eletroeletrônica" },
  { id: "aluno-006", name: "Larissa Moreira", matricula: "MA-2026-092", turma: "Meca 2", sala: "Sala 203", curso: "Técnico em Mecatrônica" }
];

export const INITIAL_REGISTROS_ENTRADA: RegistroEntrada[] = [
  { id: "reg-001", aluno_id: "aluno-001", nome: "João Silva", data: TODAY_KEY, horario_entrada: "07:15", horario_saida: null, status: "Presente", liberacao_autorizada: false, liberacao_coordenador: "", liberacao_confirmada: false },
  { id: "reg-002", aluno_id: "aluno-002", nome: "Maria Clara", data: TODAY_KEY, horario_entrada: "07:10", horario_saida: null, status: "Presente", liberacao_autorizada: false, liberacao_coordenador: "", liberacao_confirmada: false },
  { id: "reg-003", aluno_id: "aluno-003", nome: "Pedro Henrique", data: TODAY_KEY, horario_entrada: "07:22", horario_saida: null, status: "Entrada registrada", liberacao_autorizada: false, liberacao_coordenador: "", liberacao_confirmada: false },
  { id: "reg-004", aluno_id: "aluno-004", nome: "Beatriz Oliveira", data: TODAY_KEY, horario_entrada: "07:18", horario_saida: null, status: "Presente", liberacao_autorizada: false, liberacao_coordenador: "", liberacao_confirmada: false },
  { id: "reg-005", aluno_id: "aluno-005", nome: "Gabriel Santos", data: TODAY_KEY, horario_entrada: "07:05", horario_saida: null, status: "Presente", liberacao_autorizada: true, liberacao_coordenador: "Coordenação", liberacao_confirmada: false },
  { id: "reg-006", aluno_id: "aluno-006", nome: "Larissa Moreira", data: TODAY_KEY, horario_entrada: "07:25", horario_saida: "08:05", status: "Saiu", liberacao_autorizada: true, liberacao_coordenador: "Ana Paula", liberacao_confirmada: true }
];

export const SCHOOL_MODEL = {
  title: "SENAI A. Jacob Lafer",
  subtitle: "Campus Santo André • Bloco principal",
  floors: [
    { label: "Bloco A", color: "#b91c1c", height: 92, windows: 9 },
    { label: "Bloco B", color: "#dc2626", height: 72, windows: 7 },
    { label: "Portaria", color: "#991b1b", height: 46, windows: 4 }
  ]
};
