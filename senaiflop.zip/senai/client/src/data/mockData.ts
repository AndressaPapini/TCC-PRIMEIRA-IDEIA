export type Student = {
  id: string;
  name: string;
  enrollment: string;
  classGroup: string;
  course: string;
  shift: string;
  avatar: string;
  status: "Ativo" | "Em aula" | "Liberado" | "Ausente";
  guardianName: string;
  guardianPhone: string;
  entryExitHistory: {
    id: string;
    type: "Entrada" | "Saída";
    time: string;
    date: string;
    gate: string;
    authorizedBy?: string;
    note?: string;
  }[];
  authorizationsHistory: {
    id: string;
    reason: string;
    date: string;
    time: string;
    status: "Autorizado" | "Pendente" | "Recusado";
    requestedBy: string;
  }[];
};

export type ExitAuthorization = {
  id: string;
  studentId: string;
  studentName: string;
  studentClass: string;
  reason: string;
  time: string;
  date: string;
  requestedBy: string;
  guardianName: string;
  guardianPhone: string;
  status: "Pendente" | "Autorizado" | "Recusado";
  decisionAt?: string;
  decidedBy?: string;
  gateConfirmedAt?: string;
  urgent?: boolean;
};

export type Room = {
  id: string;
  name: string;
  block: "Bloco A" | "Bloco B";
  type: "Sala Teórica" | "Laboratório" | "Espaço Coletivo";
  capacity: number;
  status: "Disponível" | "Ocupada" | "Reservado";
  currentClass?: string;
  features: string[];
  reservations: {
    id: string;
    startTime: string;
    endTime: string;
    date: string;
    responsible: string;
    purpose: string;
    classGroup?: string;
  }[];
};

export type UniformItem = {
  id: string;
  type: "Camiseta" | "Calça" | "Bermuda" | "Jaqueta";
  size: "PP" | "P" | "M" | "G" | "GG" | "38" | "40" | "42" | "44";
  quantity: number;
  minimumSafe: number;
  status: "Crítico" | "Baixo" | "Normal";
};

export type UniformWithdrawal = {
  id: string;
  studentName: string;
  studentClass: string;
  itemType: string;
  size: string;
  quantity: number;
  date: string;
  time: string;
  registeredBy: string;
  previousStock: number;
  remainingStock: number;
};

export type GateMovement = {
  id: string;
  type: "Entrada" | "Saída" | "Veículo" | "Visitante";
  title: string;
  subtitle: string;
  tag: string;
  time: string;
  status: string;
  plate?: string;
  driver?: string;
  destination?: string;
};

export type RealtimeActivity = {
  id: string;
  time: string;
  title: string;
  description: string;
  badge: string;
  badgeVariant: "default" | "secondary" | "destructive" | "outline" | "success" | "warning";
  timestamp: number;
};

export type FlowNotification = {
  id: string;
  title: string;
  description: string;
  time: string;
  iconType: "authorization" | "room" | "uniform" | "vehicle" | "security";
  unread: boolean;
  timestamp: number;
};

export const INITIAL_STUDENTS: Student[] = [
  {
    id: "std-1",
    name: "João Silva",
    enrollment: "DS-2026-084",
    classGroup: "DS 2",
    course: "Técnico em Desenvolvimento de Sistemas",
    shift: "Manhã",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
    status: "Ativo",
    guardianName: "Maria Silva",
    guardianPhone: "(11) 98765-4321",
    entryExitHistory: [
      { id: "mov-1", type: "Entrada", date: "29/05/2026", time: "07:15", gate: "Portaria Principal" },
      { id: "mov-2", type: "Saída", date: "28/05/2026", time: "12:10", gate: "Portaria Principal" }
    ],
    authorizationsHistory: [
      { id: "auth-h1", reason: "Consulta médica", date: "29/05/2026", time: "10:30", status: "Pendente", requestedBy: "Prof. Lucas" }
    ]
  },
  {
    id: "std-2",
    name: "Maria Clara",
    enrollment: "DS-2026-042",
    classGroup: "DS 2",
    course: "Técnico em Desenvolvimento de Sistemas",
    shift: "Manhã",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80",
    status: "Liberado",
    guardianName: "Carlos Clara",
    guardianPhone: "(11) 97412-1189",
    entryExitHistory: [
      { id: "mov-3", type: "Entrada", date: "29/05/2026", time: "07:10", gate: "Portaria Principal" },
      { id: "mov-4", type: "Saída", date: "29/05/2026", time: "08:00", gate: "Portaria Principal", authorizedBy: "Secretaria" }
    ],
    authorizationsHistory: [
      { id: "auth-h2", reason: "Saída antecipada", date: "29/05/2026", time: "08:00", status: "Autorizado", requestedBy: "Secretaria" }
    ]
  },
  {
    id: "std-3",
    name: "Pedro Henrique",
    enrollment: "DS-2026-118",
    classGroup: "DS 1",
    course: "Técnico em Desenvolvimento de Sistemas",
    shift: "Tarde",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
    status: "Ativo",
    guardianName: "Ana Souza",
    guardianPhone: "(11) 96522-3301",
    entryExitHistory: [
      { id: "mov-5", type: "Entrada", date: "29/05/2026", time: "07:22", gate: "Portaria Lateral" }
    ],
    authorizationsHistory: [
      { id: "auth-h3", reason: "Compromisso familiar", date: "29/05/2026", time: "11:00", status: "Pendente", requestedBy: "Prof. Ana" }
    ]
  },
  {
    id: "std-4",
    name: "Beatriz Oliveira",
    enrollment: "DS-2026-015",
    classGroup: "DS 2",
    course: "Técnico em Desenvolvimento de Sistemas",
    shift: "Manhã",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80",
    status: "Em aula",
    guardianName: "Renata Oliveira",
    guardianPhone: "(11) 99123-5566",
    entryExitHistory: [
      { id: "mov-6", type: "Entrada", date: "29/05/2026", time: "07:18", gate: "Portaria Principal" }
    ],
    authorizationsHistory: []
  },
  {
    id: "std-5",
    name: "Gabriel Santos",
    enrollment: "EL-2026-033",
    classGroup: "Eletro 1",
    course: "Técnico em Eletroeletrônica",
    shift: "Integral",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80",
    status: "Ativo",
    guardianName: "Marcos Santos",
    guardianPhone: "(11) 98112-9988",
    entryExitHistory: [
      { id: "mov-7", type: "Entrada", date: "29/05/2026", time: "07:05", gate: "Portaria Principal" }
    ],
    authorizationsHistory: []
  },
  {
    id: "std-6",
    name: "Larissa Moreira",
    enrollment: "MA-2026-092",
    classGroup: "Meca 2",
    course: "Técnico em Mecatrônica",
    shift: "Manhã",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80",
    status: "Em aula",
    guardianName: "Elza Moreira",
    guardianPhone: "(11) 97321-4477",
    entryExitHistory: [
      { id: "mov-8", type: "Entrada", date: "29/05/2026", time: "07:25", gate: "Portaria Principal" }
    ],
    authorizationsHistory: []
  }
];

export const INITIAL_AUTHORIZATIONS: ExitAuthorization[] = [
  {
    id: "AUTH-2026-001",
    studentId: "std-1",
    studentName: "João Silva",
    studentClass: "DS 2",
    reason: "Consulta médica",
    time: "10:30",
    date: "29/05/2026",
    requestedBy: "Prof. Lucas",
    guardianName: "Maria Silva",
    guardianPhone: "(11) 98765-4321",
    status: "Pendente",
    urgent: true
  },
  {
    id: "AUTH-2026-002",
    studentId: "std-2",
    studentName: "Maria Clara",
    studentClass: "DS 2",
    reason: "Saída antecipada",
    time: "08:00",
    date: "29/05/2026",
    requestedBy: "Secretaria",
    guardianName: "Carlos Clara",
    guardianPhone: "(11) 97412-1189",
    status: "Autorizado",
    decisionAt: "07:45",
    decidedBy: "Coordenação Pedagógica",
    gateConfirmedAt: "08:02"
  },
  {
    id: "AUTH-2026-003",
    studentId: "std-3",
    studentName: "Pedro Henrique",
    studentClass: "DS 1",
    reason: "Compromisso familiar",
    time: "11:00",
    date: "29/05/2026",
    requestedBy: "Prof. Ana",
    guardianName: "Ana Souza",
    guardianPhone: "(11) 96522-3301",
    status: "Pendente"
  }
];

export const INITIAL_ROOMS: Room[] = [
  {
    id: "sala-101",
    name: "Sala 101",
    block: "Bloco A",
    type: "Sala Teórica",
    capacity: 36,
    status: "Disponível",
    features: ["Projetor Laser", "Ar Condicionado", "36 Carteiras ergonômicas"],
    reservations: [
      {
        id: "res-1",
        date: "29/05/2026",
        startTime: "10:00",
        endTime: "12:00",
        responsible: "Prof. Marcos",
        purpose: "Aula Teórica de Banco de Dados",
        classGroup: "DS 1"
      }
    ]
  },
  {
    id: "sala-102",
    name: "Sala 102",
    block: "Bloco A",
    type: "Sala Teórica",
    capacity: 34,
    status: "Ocupada",
    currentClass: "Eletro 1 — Circuitos Digitais",
    features: ["Quadro Interativo", "Ar Condicionado"],
    reservations: [
      {
        id: "res-2",
        date: "29/05/2026",
        startTime: "07:30",
        endTime: "11:30",
        responsible: "Prof. Roberto",
        purpose: "Circuitos Digitais Práticos",
        classGroup: "Eletro 1"
      }
    ]
  },
  {
    id: "lab-info",
    name: "Laboratório",
    block: "Bloco A",
    type: "Laboratório",
    capacity: 32,
    status: "Reservado",
    features: ["32 PCs i7 / 32GB", "Monitores Duplos", "Switch Gigabit dedicado"],
    reservations: [
      {
        id: "res-3",
        date: "29/05/2026",
        startTime: "14:00",
        endTime: "16:00",
        responsible: "Prof. Lucas",
        purpose: "Desenvolvimento Web Fullstack",
        classGroup: "DS 2"
      }
    ]
  },
  {
    id: "sala-104",
    name: "Sala 104",
    block: "Bloco A",
    type: "Sala Teórica",
    capacity: 30,
    status: "Disponível",
    features: ["Projetor", "Ar Condicionado", "Mobiliário Flexível"],
    reservations: []
  },
  {
    id: "biblioteca",
    name: "Biblioteca",
    block: "Bloco B",
    type: "Espaço Coletivo",
    capacity: 60,
    status: "Disponível",
    features: ["Acervo Técnico ABNT", "Baias de Estudo Silencioso", "Wi-Fi High-Speed"],
    reservations: []
  },
  {
    id: "auditorio",
    name: "Auditório",
    block: "Bloco B",
    type: "Espaço Coletivo",
    capacity: 120,
    status: "Ocupada",
    currentClass: "Reunião de Docentes & Gestão",
    features: ["Sistema de Som Surround", "2 Telões 4K", "Iluminação Cênica"],
    reservations: [
      {
        id: "res-4",
        date: "29/05/2026",
        startTime: "16:00",
        endTime: "18:00",
        responsible: "Coordenação",
        purpose: "Alinhamento Semestral de TCC",
        classGroup: "Geral"
      }
    ]
  }
];

export const INITIAL_UNIFORMS: UniformItem[] = [
  { id: "uni-1", type: "Camiseta", size: "P", quantity: 4, minimumSafe: 10, status: "Crítico" },
  { id: "uni-2", type: "Camiseta", size: "M", quantity: 30, minimumSafe: 12, status: "Normal" },
  { id: "uni-3", type: "Camiseta", size: "G", quantity: 20, minimumSafe: 10, status: "Normal" },
  { id: "uni-4", type: "Calça", size: "40", quantity: 15, minimumSafe: 18, status: "Baixo" },
  { id: "uni-5", type: "Calça", size: "42", quantity: 24, minimumSafe: 15, status: "Normal" },
  { id: "uni-6", type: "Jaqueta", size: "M", quantity: 8, minimumSafe: 10, status: "Baixo" }
];

export const INITIAL_WITHDRAWALS: UniformWithdrawal[] = [
  {
    id: "with-1",
    studentName: "Camiseta M",
    studentClass: "DS 2",
    itemType: "Camiseta",
    size: "M",
    quantity: 1,
    date: "29/05/2026",
    time: "09:15",
    registeredBy: "Coordenação / Almoxarifado",
    previousStock: 30,
    remainingStock: 29
  },
  {
    id: "with-2",
    studentName: "Pedro Henrique",
    studentClass: "DS 1",
    itemType: "Calça",
    size: "40",
    quantity: 1,
    date: "28/05/2026",
    time: "14:20",
    registeredBy: "Almoxarifado Central",
    previousStock: 16,
    remainingStock: 15
  }
];

export const INITIAL_GATE_MOVEMENTS: GateMovement[] = [
  {
    id: "gate-1",
    type: "Entrada",
    title: "Veículo ABC-1023",
    subtitle: "Docente Prof. Carlos Alberto • Vaga Estacionamento 04",
    tag: "Entrada",
    time: "08:50",
    status: "Registrado",
    plate: "ABC-1023",
    driver: "Prof. Carlos Alberto",
    destination: "Laboratório Mecânica"
  },
  {
    id: "gate-2",
    type: "Saída",
    title: "Maria Clara",
    subtitle: "DS 2 • Saída antecipada autorizada pela Coordenação",
    tag: "Saída",
    time: "08:02",
    status: "Confirmada"
  },
  {
    id: "gate-3",
    type: "Visitante",
    title: "Prestador - Emerson Tech",
    subtitle: "Manutenção rede de fibra óptica • Acesso Bloco A",
    tag: "Visitante",
    time: "08:35",
    status: "Na unidade",
    destination: "TI / Sala de Servidores"
  },
  {
    id: "gate-4",
    type: "Veículo",
    title: "Van Escolar SP-9988",
    subtitle: "Desembarque alunos turma matutina",
    tag: "Veículo",
    time: "07:15",
    status: "Concluído",
    plate: "SP-9988"
  }
];

export const INITIAL_ACTIVITIES: RealtimeActivity[] = [
  {
    id: "act-1",
    time: "09:32",
    title: "João Silva",
    description: "Saída autorizada • Encaminhado para controle de portaria",
    badge: "Autorizado",
    badgeVariant: "success",
    timestamp: Date.now() - 2 * 60 * 1000
  },
  {
    id: "act-2",
    time: "09:21",
    title: "Laboratório — Bloco A",
    description: "Sala reservada • Prof. Lucas (DS 2)",
    badge: "Reservado",
    badgeVariant: "warning",
    timestamp: Date.now() - 13 * 60 * 1000
  },
  {
    id: "act-3",
    time: "09:15",
    title: "Camiseta M",
    description: "Retirada registrada • Quantidade: 1 • Estoque atualizado",
    badge: "Qtd: 1",
    badgeVariant: "secondary",
    timestamp: Date.now() - 19 * 60 * 1000
  },
  {
    id: "act-4",
    time: "08:50",
    title: "Veículo ABC-1023",
    description: "Entrada registrada • Acesso autorizado ao estacionamento",
    badge: "Entrada",
    badgeVariant: "default",
    timestamp: Date.now() - 44 * 60 * 1000
  },
  {
    id: "act-5",
    time: "08:12",
    title: "Nova solicitação de saída",
    description: "Enviada para coordenação • Aluno: João Silva (DS 2)",
    badge: "Pendente",
    badgeVariant: "destructive",
    timestamp: Date.now() - 82 * 60 * 1000
  }
];

export const INITIAL_NOTIFICATIONS: FlowNotification[] = [
  {
    id: "notif-1",
    title: "✓ Nova saída autorizada",
    description: "João Silva — DS 2 liberado para consulta às 10:30",
    time: "09:32",
    iconType: "authorization",
    unread: true,
    timestamp: Date.now() - 2 * 60 * 1000
  },
  {
    id: "notif-2",
    title: "🟡 Sala reservada",
    description: "Laboratório — 14:00 às 16:00 reservado com sucesso",
    time: "09:21",
    iconType: "room",
    unread: true,
    timestamp: Date.now() - 13 * 60 * 1000
  },
  {
    id: "notif-3",
    title: "👕 Uniforme retirado",
    description: "Camiseta M — 1 unidade baixada no estoque",
    time: "09:15",
    iconType: "uniform",
    unread: false,
    timestamp: Date.now() - 19 * 60 * 1000
  },
  {
    id: "notif-4",
    title: "🚗 Veículo registrado",
    description: "ABC-1023 — Entrada liberada no pátio interno",
    time: "08:12",
    iconType: "vehicle",
    unread: false,
    timestamp: Date.now() - 82 * 60 * 1000
  }
];
