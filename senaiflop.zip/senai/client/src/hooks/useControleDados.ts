import { useFlowData } from "../contexts/FlowDataContext";

export function useControleDados() {
  const data = useFlowData();
  return {
    alunos: data.alunos,
    registrosEntrada: data.registrosEntrada,
    authorizeRelease: data.authorizeRelease,
    confirmRelease: data.confirmRelease,
  };
}
