import React, { useState } from "react";
import { useFlowData } from "@/contexts/FlowDataContext";
import {
  Bell,
  CheckCircle2,
  Calendar,
  Filter,
  BarChart3,
  TrendingUp,
  FileText,
  DoorOpen,
  Building2,
  Shirt,
  Car,
  Shield,
  Sparkles,
  ArrowUpRight
} from "lucide-react";
import { toast } from "sonner";

export const NotificacoesPage: React.FC = () => {
  const { notifications, markNotificationsAsRead } = useFlowData();

  const handleMarkAll = () => {
    markNotificationsAsRead();
    toast.success("Todas as notificações foram marcadas como lidas.");
  };

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-8 animate-in fade-in duration-300">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-red-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-red-600 uppercase tracking-widest">
              Central de Eventos
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-red-500/20 text-red-600 border border-red-500/30">
              Live Feed
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight mt-1">
            Central de Notificações
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Histórico de alertas emitidos em tempo real para ações realizadas no SENAI FLOW.
          </p>
        </div>

        <button
          onClick={handleMarkAll}
          className="px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-slate-700 text-xs font-medium border border-red-100 transition-colors cursor-pointer self-start sm:self-auto"
        >
          Marcar todas como lidas
        </button>
      </div>

      <div className="rounded-3xl glass-card border border-red-100 overflow-hidden shadow-xl">
        <div className="divide-y divide-white/5">
          {notifications.map((item) => (
            <div
              key={item.id}
              className={`p-5 flex items-start gap-4 hover:bg-white/[0.02] transition-colors ${
                item.unread ? "bg-red-50/20" : ""
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-600 shrink-0 mt-0.5">
                {item.iconType === "authorization" ? (
                  <CheckCircle2 className="w-5 h-5 text-red-600" />
                ) : item.iconType === "room" ? (
                  <Building2 className="w-5 h-5 text-red-600" />
                ) : item.iconType === "uniform" ? (
                  <Shirt className="w-5 h-5 text-red-600" />
                ) : item.iconType === "vehicle" ? (
                  <Car className="w-5 h-5 text-red-600" />
                ) : (
                  <Shield className="w-5 h-5 text-red-600" />
                )}
              </div>

              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-950 flex items-center gap-2">
                    {item.title}
                    {item.unread && (
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    )}
                  </h4>
                  <span className="font-mono text-xs text-slate-500 bg-red-50 px-2 py-0.5 rounded-lg border border-red-100">
                    {item.time}
                  </span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export const RelatoriosPage: React.FC = () => {
  const { authorizations, rooms, uniforms, withdrawals, gateMovements } = useFlowData();

  const [dateStart, setDateStart] = useState("01/05/2026");
  const [dateEnd, setDateEnd] = useState("29/05/2026");
  const [activityType, setActivityType] = useState<string>("todas");

  const totalAuths = authorizations.length;
  const approvedAuths = authorizations.filter(a => a.status === "Autorizado").length;
  const totalWithdrawals = withdrawals.length;
  const totalVehicles = gateMovements.filter(m => m.type === "Veículo").length;

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-red-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-red-600 uppercase tracking-widest">
              Inteligência de Dados
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-red-500/20 text-red-600 border border-red-500/30">
              Métricas Consolidadas
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight mt-1">
            Relatórios & Auditoria
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Filtros por período e tipo de atividade para avaliação gerencial e apresentação da banca.
          </p>
        </div>

        <button
          onClick={() => toast.success("Relatório sintético exportado para PDF (simulação).")}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold shadow-lg shadow-red-600/30 transition-all cursor-pointer self-start sm:self-auto"
        >
          <FileText className="w-4 h-4" />
          <span>Exportar Relatório</span>
        </button>
      </div>

      {/* Filter Bar (Filtros: Data inicial, Data final, Tipo de atividade) */}
      <div className="p-6 rounded-3xl glass-card border border-red-100 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-1">
            Data Inicial
          </label>
          <input
            type="text"
            value={dateStart}
            onChange={(e) => setDateStart(e.target.value)}
            className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 focus:outline-none focus:border-red-500"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-1">
            Data Final
          </label>
          <input
            type="text"
            value={dateEnd}
            onChange={(e) => setDateEnd(e.target.value)}
            className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 focus:outline-none focus:border-red-500"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-1">
            Tipo de Atividade
          </label>
          <select
            value={activityType}
            onChange={(e) => setActivityType(e.target.value)}
            className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 focus:outline-none focus:border-red-500"
          >
            <option value="todas">Todas as atividades</option>
            <option value="Autorizações">Autorizações</option>
            <option value="Saídas">Saídas</option>
            <option value="Salas">Salas</option>
            <option value="Uniformes">Uniformes</option>
            <option value="Veículos">Veículos</option>
          </select>
        </div>

        <div className="flex items-end">
          <button
            onClick={() => toast.info(`Filtro aplicado: período de ${dateStart} até ${dateEnd} (${activityType})`)}
            className="w-full h-10 rounded-xl bg-red-50 hover:bg-red-100 text-slate-950 text-xs font-semibold border border-red-100 transition-colors cursor-pointer"
          >
            Aplicar Filtros
          </button>
        </div>
      </div>

      {/* Metrics Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="p-6 rounded-3xl glass-card border border-red-500/20 bg-white">
          <span className="text-xs text-slate-500 font-medium">Total de Autorizações</span>
          <div className="text-3xl font-extrabold text-slate-950 mt-2 font-mono">{totalAuths}</div>
          <p className="text-[11px] text-red-600 mt-1">Taxa de aprovação: {Math.round((approvedAuths/totalAuths)*100)}%</p>
        </div>

        <div className="p-6 rounded-3xl glass-card border border-red-500/20 bg-white">
          <span className="text-xs text-slate-500 font-medium">Salas & Laboratórios</span>
          <div className="text-3xl font-extrabold text-slate-950 mt-2 font-mono">{rooms.length}</div>
          <p className="text-[11px] text-red-600 mt-1">100% monitoradas digitalmente</p>
        </div>

        <div className="p-6 rounded-3xl glass-card border border-red-500/20 bg-white">
          <span className="text-xs text-slate-500 font-medium">Retiradas de Uniforme</span>
          <div className="text-3xl font-extrabold text-slate-950 mt-2 font-mono">{totalWithdrawals}</div>
          <p className="text-[11px] text-red-600 mt-1">Sem perdas ou divergências</p>
        </div>

        <div className="p-6 rounded-3xl glass-card border border-red-500/20 bg-white">
          <span className="text-xs text-slate-500 font-medium">Veículos Cadastrados</span>
          <div className="text-3xl font-extrabold text-slate-950 mt-2 font-mono">{totalVehicles}</div>
          <p className="text-[11px] text-red-600 mt-1">Vagas de docentes e frotas</p>
        </div>
      </div>

      {/* Graphic representation / Visual bar breakdown */}
      <div className="rounded-3xl glass-card border border-red-100 p-6 sm:p-8 space-y-6">
        <div className="flex items-center justify-between border-b border-red-100 pb-4">
          <div>
            <h3 className="text-base font-bold text-slate-950">
              Distribuição de Ocorrências Escolares
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">Percentual de demandas por setor atendido</p>
          </div>
          <span className="text-xs font-mono text-red-600">Eficiência operacional +42%</span>
        </div>

        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs font-medium mb-1">
              <span className="text-slate-700">Autorizações de Saída (Coordenação)</span>
              <span className="text-red-600 font-mono">45%</span>
            </div>
            <div className="w-full h-3 rounded-full bg-red-50 overflow-hidden">
              <div className="h-full bg-red-600 rounded-full w-[45%]" />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs font-medium mb-1">
              <span className="text-slate-700">Reservas de Laboratórios & Salas</span>
              <span className="text-red-600 font-mono">25%</span>
            </div>
            <div className="w-full h-3 rounded-full bg-red-50 overflow-hidden">
              <div className="h-full bg-red-500 rounded-full w-[25%]" />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs font-medium mb-1">
              <span className="text-slate-700">Controle de Catraca & Portaria</span>
              <span className="text-red-600 font-mono">18%</span>
            </div>
            <div className="w-full h-3 rounded-full bg-red-50 overflow-hidden">
              <div className="h-full bg-red-500 rounded-full w-[18%]" />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs font-medium mb-1">
              <span className="text-slate-700">Retiradas de Almoxarifado / Uniforme</span>
              <span className="text-red-600 font-mono">12%</span>
            </div>
            <div className="w-full h-3 rounded-full bg-red-50 overflow-hidden">
              <div className="h-full bg-red-500 rounded-full w-[12%]" />
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};
