import React, { useState } from "react";
import { useFlowData } from "@/contexts/FlowDataContext";
import { Student } from "@/data/mockData";
import {
  Users,
  Search,
  Filter,
  GraduationCap,
  Calendar,
  Phone,
  UserCheck,
  History,
  DoorOpen,
  FileCheck2,
  CheckCircle2,
  Clock,
  ArrowRight
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface AlunosViewProps {
  initialMode?: "lista" | "carometro";
}

export const AlunosPage: React.FC<AlunosViewProps> = ({ initialMode = "lista" }) => {
  const { students } = useFlowData();

  // Mode: List table or Carômetro photo cards
  const [viewMode, setViewMode] = useState<"lista" | "carometro">(initialMode);
  const [selectedClass, setSelectedClass] = useState<string>("todos");
  const [searchQuery, setSearchQuery] = useState("");

  // Student Profile Modal
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);

  const classes = ["todos", "DS 1", "DS 2", "Eletro 1", "Meca 2"];

  const filteredStudents = students.filter((s) => {
    const matchesClass = selectedClass === "todos" || s.classGroup === selectedClass;
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.enrollment.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.classGroup.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesClass && matchesSearch;
  });

  const handleOpenStudent = (s: Student) => {
    setSelectedStudent(s);
    setProfileOpen(true);
  };

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-red-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-red-600 uppercase tracking-widest">
              Corpo Discente
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-red-500/20 text-red-600 border border-red-500/30">
              SENAI A. Jacob Lafer
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight mt-1">
            {viewMode === "carometro" ? "Carômetro Digital" : "Diretório de Alunos"}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Consulte prontuários, turmas, histórico de autorizações de saída e acessos de catraca.
          </p>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-white border border-red-100 self-start sm:self-auto">
          <button
            onClick={() => setViewMode("lista")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              viewMode === "lista"
                ? "bg-red-600 text-slate-950 font-bold"
                : "text-slate-500 hover:text-slate-950"
            }`}
          >
            Lista Detalhada
          </button>
          <button
            onClick={() => setViewMode("carometro")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              viewMode === "carometro"
                ? "bg-red-600 text-slate-950 font-bold"
                : "text-slate-500 hover:text-slate-950"
            }`}
          >
            Modo Carômetro
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between bg-white p-4 rounded-2xl border border-red-100">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar aluno, número ou matrícula..."
            className="w-full h-9.5 pl-9 pr-3 rounded-xl bg-white border border-red-100 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-red-500"
          />
        </div>

        {/* Class Filter */}
        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <span className="text-xs text-slate-500 flex items-center gap-1 shrink-0">
            <Filter className="w-3.5 h-3.5" /> Turma:
          </span>
          {classes.map((cls) => (
            <button
              key={cls}
              onClick={() => setSelectedClass(cls)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
                selectedClass === cls
                  ? "bg-red-600 text-slate-950 font-semibold"
                  : "bg-red-50 text-slate-500 hover:text-slate-950"
              }`}
            >
              {cls === "todos" ? "Todas as turmas" : cls}
            </button>
          ))}
        </div>
      </div>

      {/* CARÔMETRO VIEW (Cards com foto, nome, número, status) */}
      {viewMode === "carometro" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredStudents.map((student) => (
            <div
              key={student.id}
              onClick={() => handleOpenStudent(student)}
              className="rounded-3xl p-5 glass-card glass-card-hover border border-red-100 flex flex-col items-center text-center space-y-4 cursor-pointer group relative overflow-hidden"
            >
              <div className="relative mt-2">
                <img
                  src={student.avatar}
                  alt={student.name}
                  className="w-24 h-24 rounded-2xl object-cover ring-2 ring-red-500/30 group-hover:ring-red-400 transition-all shadow-lg"
                />
                <span
                  className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-[#0f172a] ${
                    student.status === "Liberado"
                      ? "bg-red-400"
                      : student.status === "Em aula"
                      ? "bg-red-400"
                      : "bg-slate-400"
                  }`}
                />
              </div>

              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-950 group-hover:text-red-600 transition-colors">
                  {student.name}
                </h3>
                <p className="text-xs font-mono text-red-600 font-semibold">
                  {student.enrollment}
                </p>
                <p className="text-xs text-slate-500">
                  Turma: <b className="text-slate-700">{student.classGroup}</b>
                </p>
              </div>

              <div className="w-full pt-3 border-t border-red-100 flex items-center justify-between text-xs">
                <span className="text-slate-500">Status:</span>
                <span className="font-semibold text-slate-900 px-2 py-0.5 rounded-md bg-white/5">
                  {student.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* LISTA TABLE VIEW */
        <div className="rounded-3xl glass-card border border-red-100 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-red-100 bg-white text-slate-500 uppercase text-[11px] font-semibold tracking-wider">
                  <th className="py-4 px-6">Aluno</th>
                  <th className="py-4 px-4">Turma</th>
                  <th className="py-4 px-4">Matrícula</th>
                  <th className="py-4 px-4">Curso</th>
                  <th className="py-4 px-4">Status</th>
                  <th className="py-4 px-6 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredStudents.map((student) => (
                  <tr
                    key={student.id}
                    onClick={() => handleOpenStudent(student)}
                    className="hover:bg-white/[0.03] transition-colors cursor-pointer"
                  >
                    <td className="py-4 px-6 font-semibold text-slate-950 flex items-center gap-3">
                      <img
                        src={student.avatar}
                        alt={student.name}
                        className="w-9 h-9 rounded-xl object-cover ring-1 ring-white/20"
                      />
                      <span>{student.name}</span>
                    </td>
                    <td className="py-4 px-4 font-mono text-slate-700 font-bold text-xs">
                      {student.classGroup}
                    </td>
                    <td className="py-4 px-4 font-mono text-slate-500 text-xs">
                      {student.enrollment}
                    </td>
                    <td className="py-4 px-4 text-slate-700 text-xs truncate max-w-xs">
                      {student.course}
                    </td>
                    <td className="py-4 px-4">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/10 text-red-600 border border-red-500/30">
                        {student.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <button className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-600 text-slate-700 hover:text-slate-950 text-xs font-medium transition-colors border border-red-100">
                        Ver Perfil
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* STUDENT PROFILE MODAL (HISTÓRICO DE AUTORIZAÇÕES + ENTRADAS E SAÍDAS) */}
      <Dialog open={profileOpen} onOpenChange={setProfileOpen}>
        <DialogContent className="bg-white border border-red-200 text-slate-950 max-w-2xl rounded-3xl p-6 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-950">
              Prontuário Individual do Aluno
            </DialogTitle>
          </DialogHeader>

          {selectedStudent && (
            <div className="space-y-6 py-2">
              {/* Profile Card */}
              <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-2xl bg-white border border-red-100">
                <img
                  src={selectedStudent.avatar}
                  alt={selectedStudent.name}
                  className="w-20 h-20 rounded-2xl object-cover ring-2 ring-red-500/40"
                />
                <div className="space-y-1 text-center sm:text-left">
                  <div className="flex items-center justify-center sm:justify-start gap-2">
                    <h3 className="text-lg font-bold text-slate-950">{selectedStudent.name}</h3>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-red-500/20 text-red-600 font-mono font-bold">
                      {selectedStudent.classGroup}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700">{selectedStudent.course}</p>
                  <p className="text-xs text-slate-500">
                    Matrícula: <b className="font-mono text-slate-700">{selectedStudent.enrollment}</b> • Turno: {selectedStudent.shift}
                  </p>
                  <p className="text-xs text-slate-500">
                    Responsável: <b className="text-slate-700">{selectedStudent.guardianName}</b> ({selectedStudent.guardianPhone})
                  </p>
                </div>
              </div>

              {/* History Tabs / Sections */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* 1. Histórico de Autorizações de Saída */}
                <div className="p-4 rounded-2xl bg-white border border-red-100 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-red-100">
                    <FileCheck2 className="w-4 h-4 text-red-600" />
                    <h4 className="text-xs font-bold text-slate-950 uppercase tracking-wider">
                      Histórico de Autorizações
                    </h4>
                  </div>

                  {selectedStudent.authorizationsHistory.length === 0 ? (
                    <p className="text-xs text-slate-500 italic py-2">
                      Nenhuma autorização cadastrada.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {selectedStudent.authorizationsHistory.map((item) => (
                        <div key={item.id} className="p-2.5 rounded-xl bg-red-50 border border-red-100 text-xs space-y-1">
                          <div className="flex justify-between font-medium">
                            <span className="text-slate-950">{item.reason}</span>
                            <span className="text-red-600 font-bold">{item.status}</span>
                          </div>
                          <div className="flex justify-between text-slate-500 text-[11px]">
                            <span>{item.date} às {item.time}</span>
                            <span>Por: {item.requestedBy}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* 2. Histórico de Entradas e Saídas (Portaria) */}
                <div className="p-4 rounded-2xl bg-white border border-red-100 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-red-100">
                    <DoorOpen className="w-4 h-4 text-red-600" />
                    <h4 className="text-xs font-bold text-slate-950 uppercase tracking-wider">
                      Catraca & Portaria
                    </h4>
                  </div>

                  {selectedStudent.entryExitHistory.length === 0 ? (
                    <p className="text-xs text-slate-500 italic py-2">
                      Nenhum registro de catraca gravado.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {selectedStudent.entryExitHistory.map((item) => (
                        <div key={item.id} className="p-2.5 rounded-xl bg-red-50 border border-red-100 text-xs space-y-1">
                          <div className="flex justify-between font-medium">
                            <span className="text-slate-950">{item.type}</span>
                            <span className="text-red-600 font-mono">{item.time}</span>
                          </div>
                          <div className="flex justify-between text-slate-500 text-[11px]">
                            <span>{item.date}</span>
                            <span>{item.gate}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setProfileOpen(false)}
                  className="px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-slate-700 text-xs font-medium cursor-pointer"
                >
                  Fechar Prontuário
                </button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

    </div>
  );
};
