import React, { useState } from "react";
import { useFlowData } from "@/contexts/FlowDataContext";
import {
  Shield,
  CheckCircle2,
  Clock,
  Car,
  UserCheck,
  DoorOpen,
  Plus,
  Search,
  Check,
  ArrowUpRight,
  ArrowDownLeft,
  Users
} from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export const PortariaPage: React.FC = () => {
  const {
    authorizations,
    gateMovements,
    confirmGateExit,
    registerVehicleMovement,
    simulatedTime
  } = useFlowData();

  const [activeTab, setActiveTab] = useState<"autorizados" | "entradas" | "saidas" | "veiculos" | "visitantes">("autorizados");
  const [vehicleModalOpen, setVehicleModalOpen] = useState(false);
  const [vehicleData, setVehicleData] = useState({
    plate: "ABC-1023",
    driver: "Prof. Carlos Alberto",
    type: "Entrada" as "Entrada" | "Saída",
    destination: "Laboratório Mecânica — Bloco A"
  });

  // Filter authorized students waiting for exit confirmation
  const authorizedStudents = authorizations.filter((a) => a.status === "Autorizado");

  const handleConfirmExit = (authId: string, studentName: string) => {
    confirmGateExit(authId);
    toast.success(`Saída de ${studentName} confirmada!`, {
      description: `Horário registrado: ${simulatedTime}. Catraca liberada e evento registrado no log.`
    });
  };

  const handleRegisterVehicle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vehicleData.plate.trim() || !vehicleData.driver.trim()) {
      toast.warning("Preencha placa e condutor do veículo.");
      return;
    }

    registerVehicleMovement(vehicleData);
    toast.success(`Veículo ${vehicleData.plate} registrado com sucesso!`, {
      description: `${vehicleData.type} autorizada para ${vehicleData.driver}.`
    });
    setVehicleModalOpen(false);
  };

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-red-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-red-600 uppercase tracking-widest">
              Controle de Acesso Físico
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-red-500/20 text-red-600 border border-red-500/30">
              Terminal Operacional Conectado
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight mt-1">
            Portaria & Segurança
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Recepção de autorizações enviadas pela Coordenação, registro de entradas, saídas e controle veicular.
          </p>
        </div>

        <button
          onClick={() => setVehicleModalOpen(true)}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold tracking-wide shadow-lg shadow-red-600/30 transition-all cursor-pointer self-start sm:self-auto"
        >
          <Car className="w-4 h-4" />
          <span>+ Registrar Veículo</span>
        </button>
      </div>

      {/* Tabs navigation with horizontal scroll and safe shrink */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 custom-scrollbar border-b border-red-100">
        {[
          { id: "autorizados", label: "Alunos autorizados", count: authorizedStudents.length },
          { id: "entradas", label: "Entradas", count: gateMovements.filter(m => m.tag === "Entrada").length },
          { id: "saidas", label: "Saídas", count: gateMovements.filter(m => m.tag === "Saída" || m.tag === "Autorizado").length },
          { id: "veiculos", label: "Veículos", count: gateMovements.filter(m => m.type === "Veículo").length },
          { id: "visitantes", label: "Visitantes", count: gateMovements.filter(m => m.type === "Visitante").length }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-all flex items-center gap-2 ${
              activeTab === tab.id
                ? "bg-red-600 text-slate-950 font-bold shadow-md shadow-red-600/30"
                : "bg-white text-slate-700 hover:bg-white/5"
            }`}
          >
            <span>{tab.label}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
              activeTab === tab.id ? "bg-white/20 text-slate-950" : "bg-white/10 text-slate-500"
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* SECTION: Alunos Autorizados (Autorizações Recebidas da Coordenação) */}
      {activeTab === "autorizados" && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h2 className="text-base sm:text-lg font-bold text-slate-950 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-red-600 shrink-0" />
              <span>Autorizações Recebidas da Coordenação</span>
            </h2>
            <span className="text-xs text-slate-500">
              Confirme a liberação presencial quando o aluno chegar à catraca
            </span>
          </div>

          {authorizedStudents.length === 0 ? (
            <div className="p-8 text-center rounded-3xl glass-card border border-red-100 text-slate-500 text-xs">
              Nenhum aluno com autorização pendente de saída no momento.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {authorizedStudents.map((auth) => (
                <div
                  key={auth.id}
                  className="rounded-3xl p-6 glass-card border border-red-500/30 bg-gradient-to-b from-red-50/20 via-white/60 to-red-50/90 shadow-xl flex flex-col justify-between space-y-4 relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-full blur-2xl pointer-events-none" />

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-red-600 font-mono">
                        {auth.id}
                      </span>
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-500/20 text-red-600 border border-red-500/30">
                        <Check className="w-3 h-3 text-red-600" />
                        ✓ Autorizado
                      </span>
                    </div>

                    <div>
                      <h3 className="text-lg font-extrabold text-slate-950 tracking-tight uppercase">
                        {auth.studentName}
                      </h3>
                      <p className="text-xs text-red-600 font-semibold mt-0.5">
                        Turma: {auth.studentClass}
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-white border border-red-100 space-y-1.5 text-xs">
                      <div className="flex justify-between text-slate-500">
                        <span>Motivo:</span>
                        <span className="text-slate-900 font-medium">{auth.reason}</span>
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>Horário programado:</span>
                        <span className="text-red-600 font-mono font-bold">{auth.time}</span>
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>Responsável:</span>
                        <span className="text-slate-900">{auth.guardianName}</span>
                      </div>
                    </div>

                    {auth.gateConfirmedAt ? (
                      <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-600 text-xs font-semibold flex items-center justify-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-red-600" />
                        Saída registrada às {auth.gateConfirmedAt}
                      </div>
                    ) : (
                      <button
                        onClick={() => handleConfirmExit(auth.id, auth.studentName)}
                        className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold tracking-wide shadow-lg shadow-red-600/30 transition-all cursor-pointer"
                      >
                        <DoorOpen className="w-4 h-4" />
                        <span>Confirmar saída</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Movement List for other tabs */}
      {activeTab !== "autorizados" && (
        <div className="rounded-3xl glass-card border border-red-100 overflow-hidden shadow-xl">
          <div className="p-4 bg-white border-b border-red-100 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-950 capitalize">
              Registros — {activeTab}
            </h3>
            <span className="text-xs text-slate-500">Atualizado em tempo real</span>
          </div>

          <div className="divide-y divide-white/5">
            {gateMovements
              .filter((m) => {
                if (activeTab === "entradas") return m.tag === "Entrada";
                if (activeTab === "saidas") return m.tag === "Saída" || m.tag === "Autorizado";
                if (activeTab === "veiculos") return m.type === "Veículo";
                if (activeTab === "visitantes") return m.type === "Visitante";
                return true;
              })
              .map((item) => (
                <div key={item.id} className="p-4 flex items-center justify-between hover:bg-white/[0.02] transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-red-50 border border-red-100 flex items-center justify-center text-red-600">
                      {item.type === "Veículo" ? (
                        <Car className="w-5 h-5" />
                      ) : item.type === "Visitante" ? (
                        <Users className="w-5 h-5" />
                      ) : (
                        <DoorOpen className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-950">{item.title}</h4>
                      <p className="text-xs text-slate-500">{item.subtitle}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-slate-500 bg-red-50 px-2 py-1 rounded-lg border border-red-100">
                      {item.time}
                    </span>
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-red-500/20 text-red-600 border border-red-500/30">
                      {item.status}
                    </span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* NEW VEHICLE MODAL */}
      <Dialog open={vehicleModalOpen} onOpenChange={setVehicleModalOpen}>
        <DialogContent className="bg-white border border-red-200 text-slate-950 max-w-md rounded-3xl p-6 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-950 flex items-center gap-2">
              <Car className="w-5 h-5 text-red-600" />
              Registrar Movimento de Veículo
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleRegisterVehicle} className="space-y-4 py-2">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Placa do Veículo *
              </label>
              <input
                type="text"
                required
                value={vehicleData.plate}
                onChange={(e) => setVehicleData({ ...vehicleData, plate: e.target.value.toUpperCase() })}
                placeholder="Ex: ABC-1023"
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 uppercase font-mono placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Condutor / Identificação *
              </label>
              <input
                type="text"
                required
                value={vehicleData.driver}
                onChange={(e) => setVehicleData({ ...vehicleData, driver: e.target.value })}
                placeholder="Ex: Prof. Roberto ou Transportadora"
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Tipo de Fluxo *
                </label>
                <select
                  value={vehicleData.type}
                  onChange={(e) => setVehicleData({ ...vehicleData, type: e.target.value as any })}
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 focus:outline-none focus:border-red-500"
                >
                  <option value="Entrada">Entrada</option>
                  <option value="Saída">Saída</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Destino / Vaga
                </label>
                <input
                  type="text"
                  value={vehicleData.destination}
                  onChange={(e) => setVehicleData({ ...vehicleData, destination: e.target.value })}
                  placeholder="Ex: Bloco A - Estacionamento"
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <DialogFooter className="pt-4">
              <button
                type="button"
                onClick={() => setVehicleModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-red-50 text-slate-700 text-xs hover:bg-red-100 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold shadow-lg shadow-red-600/30 cursor-pointer"
              >
                Salvar registro
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

    </div>
  );
};
