import React from "react";
import { Link, useLocation } from "wouter";
import { useFlowData } from "@/contexts/FlowDataContext";
import {
  FileCheck2,
  Building2,
  Shirt,
  Shield,
  ArrowRight,
  Clock,
  Calendar as CalendarIcon,
  Sparkles,
  ChevronRight,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  BellRing,
  Layers,
  GraduationCap
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

export const Home: React.FC = () => {
  const [, setLocation] = useLocation();
  const {
    authorizations,
    rooms,
    uniforms,
    activities,
    simulatedTime,
    simulatedDate
  } = useFlowData();

  // Metrics
  const pendingAuthCount = authorizations.filter((a) => a.status === "Pendente").length;
  const availableRoomsCount = rooms.filter((r) => r.status === "Disponível").length;
  const criticalUniformsCount = uniforms.filter((u) => u.status === "Crítico").length;

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10 animate-in fade-in duration-300">
      
      {/* 1. Header Hero / Welcome Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Welcome Greeting */}
        <div className="lg:col-span-8 flex flex-col justify-between p-6 sm:p-8 rounded-3xl glass-card relative overflow-hidden bg-gradient-to-br from-white via-white/60 to-red-50/40 border border-red-100 shadow-xl">
          <div className="absolute top-0 right-0 w-80 h-80 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-600 text-xs font-semibold tracking-wide uppercase">
              <Sparkles className="w-3.5 h-3.5 text-red-600" />
              Painel Integrado de Operações
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-950 tracking-tight">
              Olá, Coordenação! 👋
            </h1>

            <p className="text-slate-700 text-sm sm:text-base max-w-2xl leading-relaxed">
              Tudo o que você precisa para organizar a escola em um só lugar. Acompanhe autorizações, salas, fluxo de portaria e estoque com sincronização instantânea.
            </p>
          </div>

          <div className="relative z-10 pt-6 mt-6 border-t border-red-100 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 text-xs sm:text-sm text-slate-700">
              <CalendarIcon className="w-4 h-4 text-red-600" />
              <span className="font-medium text-slate-950">{simulatedDate}</span>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-50 border border-red-100 text-xs text-slate-700">
                <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                <span>{pendingAuthCount} autorizações pendentes</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-50 border border-red-100 text-xs text-slate-700">
                <span className="w-2 h-2 rounded-full bg-red-400" />
                <span>{availableRoomsCount} salas livres</span>
              </div>
            </div>
          </div>
        </div>

        {/* Digital Clock & Mini Calendar Widget */}
        <div className="lg:col-span-4 flex flex-col justify-between p-6 sm:p-7 rounded-3xl glass-card bg-gradient-to-br from-red-50/40 via-white/80 to-red-50 border border-red-100 shadow-xl relative overflow-hidden">
          <div className="absolute top-2 right-2 w-32 h-32 bg-red-500/15 rounded-full blur-2xl" />

          <div className="relative z-10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-widest text-red-600 font-bold">Horário Oficial</span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-red-500/20 text-red-600 border border-red-500/30 font-medium">
                Sincronizado
              </span>
            </div>

            <div className="text-4xl sm:text-5xl font-mono font-extrabold text-slate-950 tracking-tight flex items-baseline gap-2">
              {simulatedTime}
              <span className="text-xs font-sans text-slate-500 font-medium">BRT</span>
            </div>

            <p className="text-sm font-semibold text-slate-900">Bom dia, Coordenação!</p>
            <p className="text-xs text-slate-500 italic">“Que hoje seja um grande dia!”</p>
          </div>

          {/* Mini Calendar Widget (May 2026 Simulation) */}
          <div className="relative z-10 mt-5 pt-4 border-t border-red-100">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-2.5">
              <span>Maio de 2026</span>
              <span className="text-[10px] text-red-600">Semana 22</span>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center text-[10px]">
              {["D", "S", "T", "Q", "Q", "S", "S"].map((d, i) => (
                <span key={i} className="text-slate-500 font-medium py-0.5">
                  {d}
                </span>
              ))}
              {/* Calendar Days slice around May 29 */}
              <span className="text-slate-500 py-1">24</span>
              <span className="text-slate-500 py-1">25</span>
              <span className="text-slate-500 py-1">26</span>
              <span className="text-slate-500 py-1">27</span>
              <span className="text-slate-500 py-1">28</span>
              <span className="bg-red-600 text-slate-950 font-bold rounded-lg py-1 shadow-md shadow-red-600/40 border border-red-400/40">
                29
              </span>
              <span className="text-slate-500 py-1">30</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Four Main Hub Cards (CARDS PRINCIPAIS) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-950 tracking-tight">
              Módulos Operacionais
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Acesse as principais rotinas escolares com um clique.
            </p>
          </div>
          <span className="text-xs font-medium text-slate-500 hidden sm:inline">
            Clique em "Acessar" para gerenciar
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Card 1: AUTORIZAÇÕES DE SAÍDA */}
          <div className="group rounded-3xl p-6 glass-card glass-card-hover relative flex flex-col justify-between border border-red-500/20 bg-gradient-to-b from-red-50/40 via-white/60 to-red-50/90 shadow-lg">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-600 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-slate-950 transition-all duration-300">
                  <FileCheck2 className="w-6 h-6" />
                </div>
                {pendingAuthCount > 0 && (
                  <Badge variant="destructive" className="bg-red-500/90 hover:bg-red-500 text-slate-950 text-[11px] font-bold px-2.5 py-0.5">
                    {pendingAuthCount} pendentes
                  </Badge>
                )}
              </div>

              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-red-600">
                  Módulo 01
                </span>
                <h3 className="text-lg font-bold text-slate-950 mt-1 group-hover:text-red-600 transition-colors">
                  Autorizações de Saída
                </h3>
                <p className="text-xs text-slate-700 mt-2 leading-relaxed">
                  Libere e acompanhe a saída dos alunos. Notificação em tempo real enviada direto para a portaria.
                </p>
              </div>
            </div>

            <div className="pt-6 mt-4 border-t border-red-100">
              <Link
                href="/autorizacoes"
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-semibold tracking-wide transition-all shadow-md shadow-red-600/30 group-hover:gap-3 cursor-pointer"
              >
                <span>Acessar</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Card 2: SALAS */}
          <div className="group rounded-3xl p-6 glass-card glass-card-hover relative flex flex-col justify-between border border-red-500/20 bg-gradient-to-b from-red-50/30 via-white/60 to-red-50/90 shadow-lg">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-600 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-slate-950 transition-all duration-300">
                  <Building2 className="w-6 h-6" />
                </div>
                <Badge variant="secondary" className="bg-red-500/20 text-red-600 border border-red-500/30 text-[11px]">
                  {availableRoomsCount} livres
                </Badge>
              </div>

              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-red-600">
                  Módulo 02
                </span>
                <h3 className="text-lg font-bold text-slate-950 mt-1 group-hover:text-red-600 transition-colors">
                  Salas & Laboratórios
                </h3>
                <p className="text-xs text-slate-700 mt-2 leading-relaxed">
                  Veja a disponibilidade e faça reservas. Calendário com horários de Bloco A e Bloco B integrados.
                </p>
              </div>
            </div>

            <div className="pt-6 mt-4 border-t border-red-100">
              <Link
                href="/salas"
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-50 hover:bg-red-100 text-slate-950 text-xs font-semibold tracking-wide border border-red-100 hover:border-red-500/40 transition-all group-hover:gap-3 cursor-pointer"
              >
                <span>Acessar</span>
                <ArrowRight className="w-4 h-4 text-red-600" />
              </Link>
            </div>
          </div>

          {/* Card 3: UNIFORMES */}
          <div className="group rounded-3xl p-6 glass-card glass-card-hover relative flex flex-col justify-between border border-red-500/20 bg-gradient-to-b from-red-50/30 via-white/60 to-red-50/90 shadow-lg">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-600 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-slate-950 transition-all duration-300">
                  <Shirt className="w-6 h-6" />
                </div>
                {criticalUniformsCount > 0 && (
                  <Badge variant="outline" className="border-red-500/40 text-red-600 bg-red-500/10 text-[11px]">
                    {criticalUniformsCount} críticos
                  </Badge>
                )}
              </div>

              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-red-600">
                  Módulo 03
                </span>
                <h3 className="text-lg font-bold text-slate-950 mt-1 group-hover:text-red-600 transition-colors">
                  Uniformes & Estoque
                </h3>
                <p className="text-xs text-slate-700 mt-2 leading-relaxed">
                  Controle o estoque e registre retiradas. Atualização automática de saldo e alerta de segurança.
                </p>
              </div>
            </div>

            <div className="pt-6 mt-4 border-t border-red-100">
              <Link
                href="/uniformes"
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-50 hover:bg-red-100 text-slate-950 text-xs font-semibold tracking-wide border border-red-100 hover:border-red-500/40 transition-all group-hover:gap-3 cursor-pointer"
              >
                <span>Acessar</span>
                <ArrowRight className="w-4 h-4 text-red-600" />
              </Link>
            </div>
          </div>

          {/* Card 4: PORTARIA */}
          <div className="group rounded-3xl p-6 glass-card glass-card-hover relative flex flex-col justify-between border border-red-500/20 bg-gradient-to-b from-red-50/30 via-white/60 to-red-50/90 shadow-lg">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-600 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-slate-950 transition-all duration-300">
                  <Shield className="w-6 h-6" />
                </div>
                <Badge variant="secondary" className="bg-red-500/20 text-red-600 border border-red-500/30 text-[11px]">
                  Catraca Ativa
                </Badge>
              </div>

              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-red-600">
                  Módulo 04
                </span>
                <h3 className="text-lg font-bold text-slate-950 mt-1 group-hover:text-red-600 transition-colors">
                  Controle de Portaria
                </h3>
                <p className="text-xs text-slate-700 mt-2 leading-relaxed">
                  Acompanhe entradas, saídas e veículos. Confirmação instantânea de alunos com liberação aprovada.
                </p>
              </div>
            </div>

            <div className="pt-6 mt-4 border-t border-red-100">
              <Link
                href="/portaria"
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-50 hover:bg-red-100 text-slate-950 text-xs font-semibold tracking-wide border border-red-100 hover:border-red-500/40 transition-all group-hover:gap-3 cursor-pointer"
              >
                <span>Acessar</span>
                <ArrowRight className="w-4 h-4 text-red-600" />
              </Link>
            </div>
          </div>

        </div>
      </div>

      {/* 3. Atividade em Tempo Real (ATIVIDADE EM TEMPO REAL) */}
      <div className="rounded-3xl p-6 sm:p-8 glass-card border border-red-100 bg-white shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-red-100">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-950 tracking-tight flex items-center gap-2">
                Atividade em tempo real
                <span className="w-2 h-2 rounded-full bg-red-400 animate-ping" />
              </h2>
              <p className="text-xs text-slate-500">
                Acontecimentos recentes registrados e sincronizados entre coordenação, professores e portaria.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Link
              href="/relatorios"
              className="text-xs text-red-600 hover:text-red-600 transition-colors flex items-center gap-1 font-medium cursor-pointer"
            >
              Ver histórico completo →
            </Link>
          </div>
        </div>

        {/* Activity Feed Items */}
        <div className="divide-y divide-white/5">
          {activities.map((item) => {
            const badgeClass =
              item.badgeVariant === "success"
                ? "bg-red-500/20 text-red-600 border-red-500/30"
                : item.badgeVariant === "warning"
                ? "bg-red-500/20 text-red-600 border-red-500/30"
                : item.badgeVariant === "destructive"
                ? "bg-red-500/20 text-red-300 border-red-500/30"
                : item.badgeVariant === "secondary"
                ? "bg-red-500/20 text-red-600 border-red-500/30"
                : "bg-red-500/20 text-red-600 border-red-500/30";

            return (
              <div
                key={item.id}
                className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-white/[0.02] px-3 rounded-2xl transition-colors"
              >
                <div className="flex items-start gap-4">
                  <div className="font-mono text-xs font-semibold text-slate-500 pt-0.5 whitespace-nowrap bg-red-50 px-2 py-1 rounded-lg border border-red-100">
                    {item.time}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-950 flex items-center gap-2">
                      {item.title}
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5">{item.description}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-center">
                  <span
                    className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${badgeClass}`}
                  >
                    {item.badge}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Quick TCC Presentation Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-red-50/40 via-red-50/40 to-red-50 border border-red-500/20 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-600 shrink-0">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-950">
              Projeto de Conclusão de Curso (TCC) — Desenvolvimento de Sistemas
            </h3>
            <p className="text-xs text-slate-700 mt-0.5">
              “Desenvolver uma plataforma digital capaz de centralizar processos internos do SENAI A. Jacob Lafer, tornando atividades manuais mais rápidas, organizadas e eficientes.”
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <Link
            href="/autorizacoes"
            className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-semibold transition-colors cursor-pointer"
          >
            Testar Fluxo Interativo
          </Link>
        </div>
      </div>

    </div>
  );
};
