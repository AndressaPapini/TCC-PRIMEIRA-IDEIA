import React, { useState } from "react";
import { useFlowData } from "@/contexts/FlowDataContext";
import { ExitAuthorization } from "@/data/mockData";
import {
  FileCheck2,
  Plus,
  CheckCircle2,
  XCircle,
  Clock,
  User,
  Users,
  AlertTriangle,
  Search,
  Filter,
  Check,
  Send,
  Building,
  ShieldCheck,
  Sparkles
} from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export const AuthorizationsPage: React.FC = () => {
  const { authorizations, authorizeStudent, rejectAuthorization, createAuthorization } = useFlowData();

  // Search & Filter state
  const [filterText, setFilterText] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("todos");

  // Selected Authorization Modal
  const [selectedAuth, setSelectedAuth] = useState<ExitAuthorization | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);

  // New Authorization Modal
  const [newModalOpen, setNewModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    studentName: "",
    studentClass: "DS 2",
    reason: "",
    time: "10:30",
    requestedBy: "Coordenação",
    guardianName: "",
    guardianPhone: ""
  });

  const filteredList = authorizations.filter((item) => {
    const matchesQuery =
      item.studentName.toLowerCase().includes(filterText.toLowerCase()) ||
      item.studentClass.toLowerCase().includes(filterText.toLowerCase()) ||
      item.reason.toLowerCase().includes(filterText.toLowerCase());

    if (statusFilter === "todos") return matchesQuery;
    return matchesQuery && item.status.toLowerCase() === statusFilter.toLowerCase();
  });

  const handleOpenDetail = (auth: ExitAuthorization) => {
    setSelectedAuth(auth);
    setDetailModalOpen(true);
  };

  const handleConfirmAuthorize = () => {
    if (!selectedAuth) return;

    // 1. Update status to Autorizado
    // 2. Add activity
    // 3. Create notification
    // 4. Show success toast
    // 5. Portaria notified
    authorizeStudent(selectedAuth.id);

    toast.success("✓ Aluno autorizado com sucesso.", {
      description: "Portaria foi notificada automaticamente e a catraca está liberada.",
      duration: 5000
    });

    setDetailModalOpen(false);
  };

  const handleConfirmReject = () => {
    if (!selectedAuth) return;

    rejectAuthorization(selectedAuth.id, "Indeferido pela Coordenação Pedagógica");

    toast.error("✕ Solicitação de saída recusada.", {
      description: "O solicitante e os registros internos foram atualizados com a recusa."
    });

    setDetailModalOpen(false);
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentName.trim() || !formData.reason.trim()) {
      toast.warning("Preencha todos os campos obrigatórios.");
      return;
    }

    createAuthorization(formData);

    toast.success("Nova solicitação cadastrada com sucesso!", {
      description: "A autorização foi enviada para o fluxo de aprovação da Coordenação."
    });

    setFormData({
      studentName: "",
      studentClass: "DS 2",
      reason: "",
      time: "10:30",
      requestedBy: "Coordenação",
      guardianName: "",
      guardianPhone: ""
    });
    setNewModalOpen(false);
  };

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-300">
      
      {/* Header with Title and Action Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-red-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-red-600 uppercase tracking-widest">
              Fluxo Principal
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-red-500/20 text-red-600 border border-red-500/30">
              Sincronização Ativa com Portaria
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight mt-1">
            Autorizações de Saída
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Gerencie, autorize ou recuse liberações antecipadas de estudantes de forma digital e auditável.
          </p>
        </div>

        <button
          onClick={() => setNewModalOpen(true)}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold tracking-wide shadow-lg shadow-red-600/30 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ Nova autorização</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white p-4 rounded-2xl border border-red-100">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            placeholder="Filtrar por aluno, turma ou motivo..."
            className="w-full h-9.5 pl-9 pr-3 rounded-xl bg-white border border-red-100 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-red-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <span className="text-xs text-slate-500 flex items-center gap-1 shrink-0">
            <Filter className="w-3.5 h-3.5" /> Status:
          </span>
          {[
            { id: "todos", label: "Todos" },
            { id: "pendente", label: "Pendentes" },
            { id: "autorizado", label: "Autorizados" },
            { id: "recusado", label: "Recusados" }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
                statusFilter === tab.id
                  ? "bg-red-600 text-slate-950 font-semibold"
                  : "bg-red-50 text-slate-500 hover:text-slate-950"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Table / List */}
      <div className="rounded-3xl glass-card border border-red-100 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-red-100 bg-white text-slate-500 uppercase text-[11px] font-semibold tracking-wider">
                <th className="py-4 px-6">Aluno</th>
                <th className="py-4 px-4">Turma</th>
                <th className="py-4 px-4">Motivo</th>
                <th className="py-4 px-4">Horário</th>
                <th className="py-4 px-4">Solicitante</th>
                <th className="py-4 px-4">Status</th>
                <th className="py-4 px-6 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredList.map((item) => {
                const isPending = item.status === "Pendente";
                const isAuthorized = item.status === "Autorizado";
                const isRejected = item.status === "Recusado";

                return (
                  <tr
                    key={item.id}
                    onClick={() => handleOpenDetail(item)}
                    className="hover:bg-white/[0.03] transition-colors cursor-pointer group"
                  >
                    <td className="py-4 px-6 font-semibold text-slate-950 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-600 font-bold text-xs">
                        {item.studentName.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <span>{item.studentName}</span>
                        {item.urgent && (
                          <span className="block text-[10px] text-red-400 font-medium">
                            Urgente • Consulta
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-slate-700 font-mono text-xs">
                      {item.studentClass}
                    </td>
                    <td className="py-4 px-4 text-slate-700 max-w-xs truncate">
                      {item.reason}
                    </td>
                    <td className="py-4 px-4 font-mono text-slate-700">
                      {item.time}
                    </td>
                    <td className="py-4 px-4 text-slate-500">
                      {item.requestedBy}
                    </td>
                    <td className="py-4 px-4">
                      {isPending && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-600 border border-red-500/30">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
                          Pendente
                        </span>
                      )}
                      {isAuthorized && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-600 border border-red-500/30">
                          <Check className="w-3 h-3 text-red-600" />
                          Autorizado
                        </span>
                      )}
                      {isRejected && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-300 border border-red-500/30">
                          <XCircle className="w-3 h-3 text-red-400" />
                          Recusado
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-6 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenDetail(item);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-600 text-slate-700 hover:text-slate-950 text-xs font-medium transition-colors border border-red-100"
                      >
                        Avaliar
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* DETAIL MODAL (FLUXO PRINCIPAL DA AUTORIZAÇÃO) */}
      <Dialog open={detailModalOpen} onOpenChange={setDetailModalOpen}>
        <DialogContent className="bg-white border border-red-200 text-slate-950 max-w-lg rounded-3xl p-6 shadow-2xl">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider font-bold text-red-600">
                Avaliação de Saída Antecipada
              </span>
              <span className="text-[11px] font-mono text-slate-500">
                Protocolo: {selectedAuth?.id}
              </span>
            </div>
            <DialogTitle className="text-xl font-bold text-slate-950 mt-1">
              Detalhes da Solicitação
            </DialogTitle>
          </DialogHeader>

          {selectedAuth && (
            <div className="space-y-4 py-3">
              <div className="p-4 rounded-2xl bg-white border border-red-100 space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-[11px] text-slate-500 font-medium">Aluno:</span>
                    <p className="text-sm font-bold text-slate-950">{selectedAuth.studentName}</p>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 font-medium">Turma:</span>
                    <p className="text-sm font-bold text-slate-900">{selectedAuth.studentClass}</p>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-500 font-medium">Motivo informado:</span>
                  <p className="text-sm text-slate-950 font-medium mt-0.5">{selectedAuth.reason}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-[11px] text-slate-500 font-medium">Horário previsto:</span>
                    <p className="text-sm font-mono font-bold text-red-600">{selectedAuth.time}</p>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 font-medium">Responsável cadastrado:</span>
                    <p className="text-sm font-semibold text-slate-900">{selectedAuth.guardianName || "Maria Silva"}</p>
                  </div>
                </div>

                <div className="pt-2 border-t border-red-100 flex items-center justify-between text-xs text-slate-500">
                  <span>Solicitante: <b className="text-slate-700">{selectedAuth.requestedBy}</b></span>
                  <span>Contato: <b className="text-slate-700">{selectedAuth.guardianPhone || "(11) 98765-4321"}</b></span>
                </div>
              </div>

              {/* Status information banner */}
              {selectedAuth.status === "Autorizado" && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center gap-2.5 text-xs text-red-600">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-red-600" />
                  <span>✓ Aluno autorizado com sucesso. Portaria foi notificada.</span>
                </div>
              )}

              {selectedAuth.status === "Recusado" && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center gap-2.5 text-xs text-red-300">
                  <XCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>Esta autorização foi recusada pela Coordenação.</span>
                </div>
              )}
            </div>
          )}

          <DialogFooter className="flex gap-3 sm:justify-end pt-2">
            {selectedAuth?.status === "Pendente" ? (
              <>
                <button
                  type="button"
                  onClick={handleConfirmReject}
                  className="px-4 py-2.5 rounded-xl bg-red-600/20 hover:bg-red-600 text-red-300 hover:text-slate-950 text-xs font-bold border border-red-500/30 transition-all cursor-pointer"
                >
                  Recusar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmAuthorize}
                  className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold shadow-lg shadow-red-600/30 transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Autorizar</span>
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => setDetailModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-slate-700 text-xs font-medium cursor-pointer"
              >
                Fechar
              </button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* NEW AUTHORIZATION MODAL */}
      <Dialog open={newModalOpen} onOpenChange={setNewModalOpen}>
        <DialogContent className="bg-white border border-red-200 text-slate-950 max-w-lg rounded-3xl p-6 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-950">
              Nova Solicitação de Saída
            </DialogTitle>
            <p className="text-xs text-slate-500">
              Cadastre um pedido de liberação com validação dos responsáveis legais.
            </p>
          </DialogHeader>

          <form onSubmit={handleCreateSubmit} className="space-y-4 py-2">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Nome do Aluno *
              </label>
              <input
                type="text"
                required
                value={formData.studentName}
                onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                placeholder="Ex: Gabriel Santos"
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Turma *
                </label>
                <select
                  value={formData.studentClass}
                  onChange={(e) => setFormData({ ...formData, studentClass: e.target.value })}
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 focus:outline-none focus:border-red-500"
                >
                  <option value="DS 1">DS 1 (Téc. Desenv. Sistemas)</option>
                  <option value="DS 2">DS 2 (Téc. Desenv. Sistemas)</option>
                  <option value="Eletro 1">Eletro 1 (Eletroeletrônica)</option>
                  <option value="Meca 2">Meca 2 (Mecatrônica)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Horário de Saída *
                </label>
                <input
                  type="text"
                  required
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  placeholder="Ex: 10:30"
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Motivo da Saída *
              </label>
              <input
                type="text"
                required
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                placeholder="Ex: Consulta médica, compromisso particular"
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Nome do Responsável
                </label>
                <input
                  type="text"
                  value={formData.guardianName}
                  onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
                  placeholder="Ex: Marcos Santos"
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Telefone para Contato
                </label>
                <input
                  type="text"
                  value={formData.guardianPhone}
                  onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                  placeholder="(11) 98765-4321"
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <DialogFooter className="pt-4">
              <button
                type="button"
                onClick={() => setNewModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-red-50 text-slate-700 text-xs hover:bg-red-100 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold shadow-lg shadow-red-600/30 cursor-pointer"
              >
                Salvar solicitação
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

    </div>
  );
};
