import React, { useMemo, useState } from "react";
import { Building2, Check, Clock3, DoorOpen, GraduationCap, ShieldCheck, UserCheck, Users, X } from "lucide-react";
import { toast } from "sonner";
import { useControleDados } from "../hooks/useControleDados";
import { SCHOOL_MODEL, TODAY_KEY } from "../data/attendanceData";

const initials = (name: string) => name.split(" ").slice(0, 2).map((part) => part[0]).join("").toUpperCase();

function Campus3D() {
  return (
    <section className="glass-card relative overflow-hidden rounded-3xl p-5 sm:p-7 min-h-[300px] bg-gradient-to-br from-white via-red-50/35 to-white">
      <div className="absolute -right-16 -top-20 h-56 w-56 rounded-full bg-red-200/35 blur-3xl" />
      <div className="relative z-10 flex items-start justify-between gap-4">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-red-700">Modelo 3D institucional</p>
          <h2 className="mt-2 text-xl font-extrabold tracking-tight text-slate-950">{SCHOOL_MODEL.title}</h2>
          <p className="mt-1 text-xs text-slate-600">{SCHOOL_MODEL.subtitle}</p>
        </div>
        <div className="rounded-2xl border border-red-200 bg-white/80 p-3 text-red-700 shadow-sm"><Building2 className="h-5 w-5" /></div>
      </div>
      <div className="campus-3d mt-7 flex items-end justify-center gap-2 sm:gap-3" aria-label="Modelo 3D ilustrativo do campus SENAI A. Jacob Lafer">
        {SCHOOL_MODEL.floors.map((floor, index) => (
          <div key={floor.label} className="campus-building" style={{ height: floor.height, zIndex: 10 - index }}>
            <div className="campus-roof" style={{ background: floor.color }} />
            <div className="campus-face" style={{ background: `linear-gradient(135deg, ${floor.color}, #450a0a)` }}>
              <div className="campus-windows">{Array.from({ length: floor.windows }).map((_, i) => <span key={i} />)}</div>
              <div className="campus-label">{floor.label}</div>
            </div>
          </div>
        ))}
        <div className="campus-ground" />
      </div>
      <div className="relative z-10 mt-4 flex items-center justify-between text-[11px] text-slate-500">
        <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-red-600" /> Portaria principal conectada</span>
        <span>Vista isométrica</span>
      </div>
    </section>
  );
}

export function StudentReleasePage() {
  const { alunos, registrosEntrada, authorizeRelease, confirmRelease } = useControleDados();
  const [coordinator, setCoordinator] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);

  const todayRecords = useMemo(() => registrosEntrada.filter((record) => record.data === TODAY_KEY), [registrosEntrada]);
  const studentsById = useMemo(() => new Map(alunos.map((student) => [student.id, student])), [alunos]);
  const present = todayRecords.filter((record) => record.status !== "Saiu" && !record.liberacao_autorizada);
  const waitingGate = todayRecords.filter((record) => record.liberacao_autorizada && !record.liberacao_confirmada && record.status !== "Saiu");
  const activeCount = todayRecords.filter((record) => record.status !== "Saiu").length;

  const handleAuthorize = (recordId: string) => {
    if (!coordinator.trim()) {
      toast.error("Informe seu nome antes de autorizar uma saída.", { description: "O nome do coordenador fica registrado na auditoria." });
      return;
    }
    setBusyId(recordId);
    const result = authorizeRelease(recordId, coordinator.trim());
    setBusyId(null);
    if (result.success) toast.success("Saída autorizada com sucesso.", { description: "A solicitação foi encaminhada para confirmação da portaria." });
    else toast.error(result.message || "Não foi possível autorizar a saída.");
  };

  const handleConfirm = (recordId: string) => {
    setBusyId(recordId);
    const result = confirmRelease(recordId);
    setBusyId(null);
    if (result.success) toast.success("Saída confirmada na portaria.", { description: `Horário registrado: ${result.horario_saida}.` });
    else toast.error(result.message || "Não foi possível confirmar a saída.");
  };

  const StudentRow = ({ record, waiting = false }: { record: typeof todayRecords[number]; waiting?: boolean }) => {
    const student = studentsById.get(record.aluno_id);
    if (!student) return null;
    return (
      <article className={`rounded-2xl border p-4 transition-all ${waiting ? "border-amber-300 bg-amber-50/80 shadow-[0_10px_28px_-18px_rgba(180,83,9,.55)]" : "border-red-100 bg-white hover:border-red-300 hover:shadow-lg"}`}>
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex min-w-0 items-center gap-3">
            <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-sm font-extrabold ${waiting ? "bg-amber-200 text-amber-900" : "bg-red-100 text-red-700"}`}>{initials(student.name)}</div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2"><h3 className="font-bold text-slate-950">{student.name}</h3><span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${waiting ? "bg-amber-200 text-amber-900" : "bg-red-100 text-red-700"}`}>{waiting ? "Aguardando portaria" : record.status}</span></div>
              <p className="mt-1 text-xs text-slate-500">Matrícula {student.matricula} • {student.turma} • {student.sala}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-x-5 gap-y-2 text-xs text-slate-600 sm:grid-cols-4 lg:min-w-[500px]">
            <span><b className="block text-[10px] uppercase tracking-wider text-slate-400">Entrada</b>{record.horario_entrada}</span>
            <span><b className="block text-[10px] uppercase tracking-wider text-slate-400">Curso</b>{student.curso.replace("Técnico em ", "")}</span>
            <span><b className="block text-[10px] uppercase tracking-wider text-slate-400">Coordenação</b>{record.liberacao_coordenador || "—"}</span>
            <button disabled={busyId === record.id} onClick={() => waiting ? handleConfirm(record.id) : handleAuthorize(record.id)} className={`col-span-2 inline-flex min-h-10 items-center justify-center gap-2 rounded-xl px-3 text-xs font-bold transition active:scale-[.98] sm:col-span-1 ${waiting ? "bg-amber-500 text-white hover:bg-amber-600" : "bg-red-600 text-white hover:bg-red-700"}`}>
              {busyId === record.id ? <Clock3 className="h-4 w-4 animate-spin" /> : waiting ? <ShieldCheck className="h-4 w-4" /> : <UserCheck className="h-4 w-4" />}
              {waiting ? "Confirmar saída" : "Autorizar saída"}
            </button>
          </div>
        </div>
      </article>
    );
  };

  return (
    <div className="container max-w-[1400px] mx-auto px-4 py-8 sm:px-6 lg:py-10">
      <div className="grid gap-6 xl:grid-cols-[1.4fr_.8fr]">
        <div>
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div><div className="mb-3 inline-flex items-center gap-2 rounded-full border border-red-200 bg-red-50 px-3 py-1 text-[10px] font-bold uppercase tracking-[.18em] text-red-700"><DoorOpen className="h-3.5 w-3.5" /> Controle de presença</div><h1 className="text-3xl font-extrabold tracking-tight text-slate-950 sm:text-4xl">Liberação de Alunos</h1><p className="mt-2 max-w-2xl text-sm text-slate-600">Autorize a saída na Coordenação e confirme a liberação física na Portaria em duas etapas auditáveis.</p></div>
            <div className="flex items-center gap-2 rounded-2xl border border-red-100 bg-white px-4 py-3 text-xs text-slate-600 shadow-sm"><Users className="h-4 w-4 text-red-600" /><b className="text-slate-950">{activeCount}</b> alunos no campus</div>
          </div>
          <div className="mb-6 rounded-2xl border border-red-200 bg-white p-4 shadow-sm"><label htmlFor="coordinator" className="mb-2 block text-xs font-bold uppercase tracking-wider text-red-700">Coordenador responsável</label><div className="flex flex-col gap-3 sm:flex-row"><input id="coordinator" value={coordinator} onChange={(e) => setCoordinator(e.target.value)} placeholder="Digite seu nome antes de autorizar" className="h-11 flex-1 rounded-xl border border-red-100 bg-red-50/30 px-4 text-sm text-slate-950 outline-none transition focus:border-red-500 focus:ring-2 focus:ring-red-200" /><div className="flex items-center gap-2 rounded-xl bg-red-50 px-3 text-xs text-red-700"><ShieldCheck className="h-4 w-4" /> Registro obrigatório</div></div></div>
          {waitingGate.length > 0 && <section className="mb-6"><div className="mb-3 flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-amber-700">Etapa 2 • Portaria</p><h2 className="text-xl font-extrabold text-slate-950">Aguardando confirmação da portaria</h2></div><span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-800">{waitingGate.length} aguardando</span></div><div className="space-y-3">{waitingGate.map((record) => <StudentRow key={record.id} record={record} waiting />)}</div></section>}
          <section><div className="mb-3 flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-red-700">Etapa 1 • Coordenação</p><h2 className="text-xl font-extrabold text-slate-950">Alunos presentes</h2></div><span className="rounded-full bg-red-100 px-3 py-1 text-xs font-bold text-red-700">{present.length} disponíveis</span></div>{present.length === 0 ? <div className="rounded-2xl border border-dashed border-red-200 bg-white p-10 text-center"><Check className="mx-auto h-8 w-8 text-red-500" /><p className="mt-3 font-semibold text-slate-950">Nenhum aluno presente no momento.</p><p className="mt-1 text-sm text-slate-500">As liberações pendentes aparecem na seção de confirmação da portaria.</p></div> : <div className="space-y-3">{present.map((record) => <StudentRow key={record.id} record={record} />)}</div>}</section>
        </div>
        <div className="space-y-6"><Campus3D /><div className="glass-card rounded-3xl p-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-red-100 p-2 text-red-700"><GraduationCap className="h-5 w-5" /></div><div><h3 className="font-bold text-slate-950">Fluxo operacional</h3><p className="text-xs text-slate-500">Presença do dia • {todayRecords[0]?.data || "Hoje"}</p></div></div><div className="mt-5 space-y-3 text-sm"><div className="flex items-center gap-3"><span className="flex h-7 w-7 items-center justify-center rounded-full bg-red-600 text-xs font-bold text-white">1</span><span className="text-slate-700">Coordenação registra a autorização</span></div><div className="ml-3.5 h-5 border-l border-dashed border-red-300" /><div className="flex items-center gap-3"><span className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-white">2</span><span className="text-slate-700">Portaria confirma a saída física</span></div></div></div></div>
      </div>
    </div>
  );
}
