import React, { useState } from "react";
import { useFlowData } from "@/contexts/FlowDataContext";
import {
  Shirt,
  Plus,
  AlertTriangle,
  History,
  CheckCircle2,
  Package,
  Layers,
  ArrowDownRight,
  TrendingDown,
  RotateCcw
} from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export const UniformesPage: React.FC = () => {
  const { uniforms, withdrawals, registerUniformWithdrawal } = useFlowData();

  const [withdrawalModalOpen, setWithdrawalModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    studentName: "João Silva",
    studentClass: "DS 2",
    itemType: "Camiseta" as "Camiseta" | "Calça" | "Bermuda" | "Jaqueta",
    size: "M",
    quantity: 1,
    registeredBy: "Coordenação"
  });

  const [lastResult, setLastResult] = useState<{
    previousStock: number;
    remainingStock: number;
    withdrawn: number;
  } | null>(null);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();

    const res = registerUniformWithdrawal({
      studentName: formData.studentName,
      studentClass: formData.studentClass,
      itemType: formData.itemType,
      size: formData.size,
      quantity: Number(formData.quantity),
      registeredBy: formData.registeredBy
    });

    if (!res.success) {
      toast.error(res.message || "Erro ao registrar retirada.");
      return;
    }

    setLastResult({
      previousStock: res.previousStock!,
      remainingStock: res.remainingStock!,
      withdrawn: Number(formData.quantity)
    });

    toast.success("Retirada registrada com sucesso!", {
      description: `Estoque anterior: ${res.previousStock} | Retirada: ${formData.quantity} | Estoque restante: ${res.remainingStock}`,
      duration: 6000
    });

    setWithdrawalModalOpen(false);
  };

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-red-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-red-600 uppercase tracking-widest">
              Almoxarifado Escolar
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-red-500/20 text-red-600 border border-red-500/30">
              Cálculo Automático de Saldo
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight mt-1">
            Controle de Uniformes
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Acompanhe o estoque de vestuário institucional, registre retiradas de alunos e visualize alertas de reposição.
          </p>
        </div>

        <button
          onClick={() => {
            setLastResult(null);
            setWithdrawalModalOpen(true);
          }}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold tracking-wide shadow-lg shadow-red-600/30 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ Registrar retirada</span>
        </button>
      </div>

      {/* Stock Subtraction Feedback Highlight if action just occurred */}
      {lastResult && (
        <div className="p-4 rounded-2xl bg-red-50/40 border border-red-500/30 flex items-center justify-between animate-in zoom-in-95 duration-200">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-red-600/20 text-red-600">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-950">
                Última movimentação de estoque processada:
              </p>
              <p className="text-xs text-red-700">
                Quantidade anterior: <b>{lastResult.previousStock}</b> → Retirada: <b>{lastResult.withdrawn}</b> → Estoque restante: <b>{lastResult.remainingStock}</b>
              </p>
            </div>
          </div>
          <button
            onClick={() => setLastResult(null)}
            className="text-xs text-red-600 hover:text-slate-950 underline cursor-pointer"
          >
            Fechar aviso
          </button>
        </div>
      )}

      {/* Table: Tipo | Tamanho | Quantidade | Status */}
      <div className="rounded-3xl glass-card border border-red-100 overflow-hidden shadow-xl">
        <div className="p-4 bg-white border-b border-red-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-950 flex items-center gap-2">
            <Package className="w-4 h-4 text-red-600" />
            Inventário Atual de Vestuário
          </h2>
          <span className="text-xs text-slate-500">SENAI A. Jacob Lafer</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-red-100 bg-white text-slate-500 uppercase text-[11px] font-semibold tracking-wider">
                <th className="py-4 px-6">Tipo</th>
                <th className="py-4 px-6">Tamanho</th>
                <th className="py-4 px-6">Quantidade</th>
                <th className="py-4 px-6">Status</th>
                <th className="py-4 px-6 text-right">Ação rápida</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {uniforms.map((item) => {
                const isCritical = item.status === "Crítico";
                const isLow = item.status === "Baixo";

                return (
                  <tr key={item.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-4 px-6 font-bold text-slate-950 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-600">
                        <Shirt className="w-4 h-4" />
                      </div>
                      <span>{item.type}</span>
                    </td>
                    <td className="py-4 px-6 font-mono font-bold text-slate-900">
                      {item.size}
                    </td>
                    <td className="py-4 px-6 font-mono font-extrabold text-slate-950 text-base">
                      {item.quantity}
                    </td>
                    <td className="py-4 px-6">
                      {isCritical && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-300 border border-red-500/30">
                          <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                          Crítico
                        </span>
                      )}
                      {isLow && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-600 border border-red-500/30">
                          Baixo
                        </span>
                      )}
                      {!isCritical && !isLow && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-600 border border-red-500/30">
                          Normal
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-6 text-right">
                      <button
                        onClick={() => {
                          setFormData((prev) => ({
                            ...prev,
                            itemType: item.type,
                            size: item.size
                          }));
                          setWithdrawalModalOpen(true);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-600 text-slate-700 hover:text-slate-950 text-xs font-medium transition-colors border border-red-100 cursor-pointer"
                      >
                        Retirar
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Histórico de Retiradas (Adicionar histórico de retiradas) */}
      <div className="rounded-3xl glass-card border border-red-100 overflow-hidden shadow-xl">
        <div className="p-4 bg-white border-b border-red-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-950 flex items-center gap-2">
            <History className="w-4 h-4 text-red-600" />
            Histórico Recente de Retiradas
          </h2>
          <span className="text-xs text-slate-500">Últimos registros auditados</span>
        </div>

        <div className="divide-y divide-white/5">
          {withdrawals.map((w) => (
            <div key={w.id} className="p-4 flex items-center justify-between hover:bg-white/[0.02] transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-red-50/60 border border-red-500/20 flex items-center justify-center text-red-600">
                  <ArrowDownRight className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-950">
                    {w.studentName} — {w.studentClass}
                  </h4>
                  <p className="text-xs text-slate-500">
                    Item: <b>{w.itemType} (Tam. {w.size})</b> • Quantidade: {w.quantity} • Responsável: {w.registeredBy}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 text-right">
                <div className="hidden sm:block text-xs text-slate-500">
                  <span>Saldo: {w.previousStock} → </span>
                  <b className="text-red-600">{w.remainingStock}</b>
                </div>
                <span className="font-mono text-xs text-slate-500 bg-red-50 px-2 py-1 rounded-lg border border-red-100">
                  {w.time}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* WITHDRAWAL MODAL */}
      <Dialog open={withdrawalModalOpen} onOpenChange={setWithdrawalModalOpen}>
        <DialogContent className="bg-white border border-red-200 text-slate-950 max-w-md rounded-3xl p-6 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-950 flex items-center gap-2">
              <Shirt className="w-5 h-5 text-red-600" />
              Registrar Retirada de Uniforme
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleRegister} className="space-y-4 py-2">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Pessoa / Aluno *
              </label>
              <input
                type="text"
                required
                value={formData.studentName}
                onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                placeholder="Ex: João Silva"
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Turma
              </label>
              <input
                type="text"
                value={formData.studentClass}
                onChange={(e) => setFormData({ ...formData, studentClass: e.target.value })}
                placeholder="Ex: DS 2"
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Produto *
                </label>
                <select
                  value={formData.itemType}
                  onChange={(e) => setFormData({ ...formData, itemType: e.target.value as any })}
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 focus:outline-none focus:border-red-500"
                >
                  <option value="Camiseta">Camiseta</option>
                  <option value="Calça">Calça</option>
                  <option value="Jaqueta">Jaqueta</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Tamanho *
                </label>
                <select
                  value={formData.size}
                  onChange={(e) => setFormData({ ...formData, size: e.target.value })}
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 focus:outline-none focus:border-red-500"
                >
                  <option value="P">P</option>
                  <option value="M">M</option>
                  <option value="G">G</option>
                  <option value="40">40</option>
                  <option value="42">42</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Quantidade *
              </label>
              <input
                type="number"
                min="1"
                max="10"
                required
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: Number(e.target.value) })}
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <DialogFooter className="pt-4">
              <button
                type="button"
                onClick={() => setWithdrawalModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-red-50 text-slate-700 text-xs hover:bg-red-100 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold shadow-lg shadow-red-600/30 cursor-pointer"
              >
                Registrar retirada
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

    </div>
  );
};
