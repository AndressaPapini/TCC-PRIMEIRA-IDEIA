import React, { useState } from "react";
import { useFlowData } from "@/contexts/FlowDataContext";
import { Room } from "@/data/mockData";
import {
  Building2,
  Calendar,
  Clock,
  Plus,
  Users,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Monitor,
  Flame,
  BookOpen
} from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export const SalasPage: React.FC = () => {
  const { rooms, reserveRoom } = useFlowData();

  const [reserveModalOpen, setReserveModalOpen] = useState(false);
  const [selectedRoomId, setSelectedRoomId] = useState<string>("sala-101");
  const [selectedDay, setSelectedDay] = useState("29/05/2026");

  const [reserveForm, setReserveForm] = useState({
    roomId: "sala-101",
    date: "29/05/2026",
    startTime: "10:00",
    endTime: "12:00",
    responsible: "Prof. Lucas",
    purpose: "Aula prática de Sistemas Embarcados",
    classGroup: "DS 2"
  });

  const blocoA = rooms.filter((r) => r.block === "Bloco A");
  const blocoB = rooms.filter((r) => r.block === "Bloco B");

  const handleOpenReserve = (roomId?: string) => {
    if (roomId) {
      setReserveForm((prev) => ({ ...prev, roomId }));
    }
    setReserveModalOpen(true);
  };

  const handleConfirmReservation = (e: React.FormEvent) => {
    e.preventDefault();

    reserveRoom({
      roomId: reserveForm.roomId,
      date: reserveForm.date,
      startTime: reserveForm.startTime,
      endTime: reserveForm.endTime,
      responsible: reserveForm.responsible,
      purpose: reserveForm.purpose,
      classGroup: reserveForm.classGroup
    });

    const targetRoom = rooms.find((r) => r.id === reserveForm.roomId);
    toast.success(`Sala "${targetRoom?.name || 'Ambiente'}" reservada com sucesso!`, {
      description: `Período: ${reserveForm.startTime} às ${reserveForm.endTime} • Status alterado para Reservado.`
    });

    setReserveModalOpen(false);
  };

  // Schedule agenda items
  const scheduleAgenda = [
    { time: "10:00 — 12:00", room: "Sala 101", classGroup: "DS 1", purpose: "Modelagem de Sistemas", responsible: "Prof. Marcos" },
    { time: "14:00 — 16:00", room: "Laboratório", classGroup: "DS 2", purpose: "Desenvolvimento Fullstack & TCC", responsible: "Prof. Lucas" },
    { time: "16:00 — 18:00", room: "Auditório", classGroup: "Reunião Geral", purpose: "Reunião de Coordenação & Alinhamento", responsible: "Coordenação" }
  ];

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-red-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-red-600 uppercase tracking-widest">
              Espaços & Infraestrutura
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-red-500/20 text-red-600 border border-red-500/30">
              Controle de Ambientes em Tempo Real
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight mt-1">
            Reserva de Salas & Laboratórios
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Monitore a ocupação de salas de aula teóricas, laboratórios de informática e auditório do SENAI A. Jacob Lafer.
          </p>
        </div>

        <button
          onClick={() => handleOpenReserve()}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold tracking-wide shadow-lg shadow-red-600/30 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ Reservar sala</span>
        </button>
      </div>

      {/* Grid of Blocks: BLOCO A and BLOCO B */}
      <div className="space-y-8">
        
        {/* BLOCO A */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
              <h2 className="text-lg font-bold text-slate-950 tracking-tight">BLOCO A — Salas Teóricas e Laboratórios</h2>
            </div>
            <span className="text-xs text-slate-500">4 ambientes cadastrados</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {blocoA.map((room) => {
              const isAvailable = room.status === "Disponível";
              const isOccupied = room.status === "Ocupada";
              const isReserved = room.status === "Reservado";

              return (
                <div
                  key={room.id}
                  className="rounded-3xl p-5 glass-card border border-red-100 flex flex-col justify-between space-y-4 relative overflow-hidden group hover:border-red-500/30 transition-all"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-semibold text-slate-500">
                        Capacidade: {room.capacity}
                      </span>
                      {isAvailable && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-500/20 text-red-600 border border-red-500/30">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                          🟢 Disponível
                        </span>
                      )}
                      {isOccupied && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-500/20 text-red-300 border border-red-500/30">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                          🔴 Ocupada
                        </span>
                      )}
                      {isReserved && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-500/20 text-red-600 border border-red-500/30">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                          🟡 Reservado
                        </span>
                      )}
                    </div>

                    <div>
                      <h3 className="text-lg font-bold text-slate-950 group-hover:text-red-600 transition-colors">
                        {room.name}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">{room.type}</p>
                    </div>

                    {room.currentClass && (
                      <div className="p-2.5 rounded-xl bg-white border border-red-100 text-[11px] text-slate-700">
                        <span className="text-slate-500 block text-[10px]">Ocupação atual:</span>
                        <b>{room.currentClass}</b>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {room.features.slice(0, 2).map((feat, idx) => (
                        <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 text-slate-700">
                          {feat}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-red-100">
                    <button
                      onClick={() => handleOpenReserve(room.id)}
                      className="w-full py-2 rounded-xl bg-red-50 hover:bg-red-600 text-slate-900 hover:text-slate-950 text-xs font-semibold transition-all border border-red-100 cursor-pointer"
                    >
                      Reservar Sala
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* BLOCO B */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
              <h2 className="text-lg font-bold text-slate-950 tracking-tight">BLOCO B — Espaços Coletivos e Multiuso</h2>
            </div>
            <span className="text-xs text-slate-500">2 ambientes cadastrados</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {blocoB.map((room) => {
              const isAvailable = room.status === "Disponível";
              const isOccupied = room.status === "Ocupada";
              const isReserved = room.status === "Reservado";

              return (
                <div
                  key={room.id}
                  className="rounded-3xl p-6 glass-card border border-red-100 flex flex-col justify-between space-y-4 relative overflow-hidden group hover:border-red-500/30 transition-all"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-semibold text-slate-500">
                        Capacidade: {room.capacity} pessoas
                      </span>
                      {isAvailable && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-600 border border-red-500/30">
                          🟢 Disponível
                        </span>
                      )}
                      {isOccupied && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-300 border border-red-500/30">
                          🔴 Ocupado
                        </span>
                      )}
                      {isReserved && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-600 border border-red-500/30">
                          🟡 Reservado
                        </span>
                      )}
                    </div>

                    <div>
                      <h3 className="text-xl font-bold text-slate-950 group-hover:text-red-600 transition-colors">
                        {room.name}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">{room.type}</p>
                    </div>

                    {room.currentClass && (
                      <div className="p-3 rounded-xl bg-white border border-red-100 text-xs text-slate-700">
                        <span className="text-slate-500 block text-[10px]">Atividade em andamento:</span>
                        <b>{room.currentClass}</b>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2 pt-1">
                      {room.features.map((feat, idx) => (
                        <span key={idx} className="text-xs px-2.5 py-1 rounded-lg bg-white/5 text-slate-700">
                          {feat}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-red-100">
                    <button
                      onClick={() => handleOpenReserve(room.id)}
                      className="w-full py-2.5 rounded-xl bg-red-50 hover:bg-red-600 text-slate-900 hover:text-slate-950 text-xs font-semibold transition-all border border-red-100 cursor-pointer"
                    >
                      Reservar Espaço
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* SECTION: CALENDÁRIO DE SALAS (Visualização de agenda conforme prompt) */}
      <div className="rounded-3xl glass-card border border-red-100 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-red-100">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-red-600" />
              <h3 className="text-lg font-bold text-slate-950">
                Calendário e Agenda de Salas
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Grade horária programada para os laboratórios e salas didáticas.
            </p>
          </div>

          {/* Trocar Dia Widget */}
          <div className="flex items-center gap-2 bg-white p-1.5 rounded-xl border border-red-100 self-start sm:self-auto">
            <button
              onClick={() => {
                setSelectedDay("28/05/2026");
                toast.info("Visualizando agenda do dia 28 de maio.");
              }}
              className="p-1 rounded-lg hover:bg-white/10 text-slate-500 hover:text-slate-950 transition-colors cursor-pointer"
              title="Dia anterior"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold px-3 text-slate-950">
              {selectedDay === "29/05/2026" ? "Quinta, 29/05 (Hoje)" : "Quarta, 28/05 (Ontem)"}
            </span>
            <button
              onClick={() => {
                setSelectedDay("29/05/2026");
                toast.info("Visualizando agenda de hoje (29/05).");
              }}
              className="p-1 rounded-lg hover:bg-white/10 text-slate-500 hover:text-slate-950 transition-colors cursor-pointer"
              title="Próximo dia"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Agenda Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {scheduleAgenda.map((slot, index) => (
            <div
              key={index}
              className="p-5 rounded-2xl bg-white border border-red-100 space-y-3 hover:border-red-500/30 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-red-600 bg-red-500/10 px-2.5 py-1 rounded-lg border border-red-500/20">
                  {slot.time}
                </span>
                <span className="text-xs font-semibold text-slate-700">
                  {slot.classGroup}
                </span>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-950">
                  {slot.room} — {slot.classGroup}
                </h4>
                <p className="text-xs text-slate-500 mt-1">{slot.purpose}</p>
              </div>

              <div className="pt-2 border-t border-red-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Responsável:</span>
                <span className="text-slate-900 font-medium">{slot.responsible}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* RESERVE MODAL */}
      <Dialog open={reserveModalOpen} onOpenChange={setReserveModalOpen}>
        <DialogContent className="bg-white border border-red-200 text-slate-950 max-w-lg rounded-3xl p-6 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-950 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-red-600" />
              Reservar Sala ou Laboratório
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleConfirmReservation} className="space-y-4 py-2">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Sala desejada *
              </label>
              <select
                value={reserveForm.roomId}
                onChange={(e) => setReserveForm({ ...reserveForm, roomId: e.target.value })}
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 focus:outline-none focus:border-red-500"
              >
                {rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} ({r.block} • {r.type} • {r.status})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Data *
                </label>
                <input
                  type="text"
                  required
                  value={reserveForm.date}
                  onChange={(e) => setReserveForm({ ...reserveForm, date: e.target.value })}
                  placeholder="29/05/2026"
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Horário inicial *
                </label>
                <input
                  type="text"
                  required
                  value={reserveForm.startTime}
                  onChange={(e) => setReserveForm({ ...reserveForm, startTime: e.target.value })}
                  placeholder="14:00"
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Horário final *
                </label>
                <input
                  type="text"
                  required
                  value={reserveForm.endTime}
                  onChange={(e) => setReserveForm({ ...reserveForm, endTime: e.target.value })}
                  placeholder="16:00"
                  className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Responsável pelo agendamento *
              </label>
              <input
                type="text"
                required
                value={reserveForm.responsible}
                onChange={(e) => setReserveForm({ ...reserveForm, responsible: e.target.value })}
                placeholder="Ex: Prof. Lucas ou Coordenação"
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Finalidade / Aula *
              </label>
              <input
                type="text"
                required
                value={reserveForm.purpose}
                onChange={(e) => setReserveForm({ ...reserveForm, purpose: e.target.value })}
                placeholder="Ex: Apresentação de TCC / Prática Web"
                className="w-full h-10 px-3 rounded-xl bg-white border border-red-100 text-xs text-slate-950 placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <DialogFooter className="pt-4">
              <button
                type="button"
                onClick={() => setReserveModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-red-50 text-slate-700 text-xs hover:bg-red-100 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-slate-950 text-xs font-bold shadow-lg shadow-red-600/30 cursor-pointer"
              >
                Confirmar reserva
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

    </div>
  );
};
